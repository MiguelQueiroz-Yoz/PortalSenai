<?php
include "conexao.php";

$salas = [];
$data_inicial = $_GET['data_inicial'] ?? null;
$data_final = $_GET['data_final'] ?? null;

if ($data_inicial && $data_final) {
    $sql = "SELECT numero_sala, nome_instrutor, nome_turma, nome_materia, data_aula, periodo, tipo_aula 
            FROM aulas 
            WHERE data_aula BETWEEN ? AND ?
            ORDER BY data_aula, numero_sala";

    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ss", $data_inicial, $data_final);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $salas[] = $row;
        }
        $stmt->close();
    } else {
        echo "Erro na preparação da consulta.";
    }
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas - Sala</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="salas.php">Salas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horários</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
    <h1>Consulta de Salas</h1>
    <form method="get" action="">
        <label>Data Inicial: <input type="date" name="data_inicial" required></label>
        <label>Data Final: <input type="date" name="data_final" required></label>
        <button type="submit">Consultar</button>
    </form>

    <?php if (!empty($salas)): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Sala</th>
                    <th>Turma</th>
                    <th>Matéria</th>
                    <th>Instrutor</th>
                    <th>Período</th>
                    <th>Tipo</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($salas)): ?>
                    <?php foreach ($salas as $sala): ?>
                        <tr>
                            <td><?= htmlspecialchars($sala['data_aula']) ?></td>
                            <td><?= htmlspecialchars($sala['numero_sala']) ?></td>
                            <td><?= htmlspecialchars($sala['nome_turma']) ?></td>
                            <td><?= htmlspecialchars($sala['nome_materia']) ?></td>
                            <td><?= htmlspecialchars($sala['nome_instrutor']) ?></td>
                            <td><?= htmlspecialchars($sala['periodo']) ?></td>
                            <td><?= htmlspecialchars($sala['tipo_aula']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php elseif ($data_inicial && $data_final): ?>
                    <tr><td colspan="7" style="text-align: center;">Nenhuma sala encontrada no período informado.</td></tr>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align: center;">Preencha o formulário acima para consultar as salas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php elseif ($data_inicial && $data_final): ?>
        <p>Nenhuma sala encontrada no período informado.</p>
    <?php endif; ?>
    <div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
            <div class="vw-plugin-top-wrapper"></div>
        </div>
        </div>
        <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
        <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
        </script>
</body>