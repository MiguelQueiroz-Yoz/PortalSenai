<?php
require_once 'conexao.php';

if (isset($_GET['fetch_data']) && $_GET['fetch_data'] === 'true') {
    header('Content-Type: application/json'); 

    $nome = $_GET['nome'] ?? ''; 
    $area = $_GET['area'] ?? ''; 

    $sql = "SELECT i.id_instrutor, i.nome_instrutor, i.email_instrutor, a.nome_area
            FROM instrutores i
            LEFT JOIN areas a ON i.id_area = a.id_area
            WHERE 1=1"; 

    $params = [];
    $types = "";

    if (!empty($nome)) {
        $sql .= " AND i.nome_instrutor LIKE ?";
        $params[] = "%" . $nome . "%";
        $types .= "s";
    }

    if (!empty($area)) {
        $sql .= " AND a.nome_area LIKE ?";
        $params[] = "%" . $area . "%";
        $types .= "s";
    }

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo json_encode(['error' => 'Erro ao preparar a consulta: ' . $conn->error]);
        close_db_connection($conn);
        exit();
    }

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        echo json_encode(['error' => 'Erro ao executar a consulta: ' . $stmt->error]);
        close_db_connection($conn);
        exit();
    }

    $result = $stmt->get_result();
    $instrutores = [];

    while ($row = $result->fetch_assoc()) {
        $instrutores[] = $row;
    }

    echo json_encode($instrutores);

    $stmt->close();
    close_db_connection($conn);
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas - Instrutor</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                                <a href="lancamento_atividades.php">Lançamento de Atividades</a>
                            </div>
                        </li>
                        <li class="dropdown active">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                        <li class=\"dropdown\">\r\n        <a href=\"#\" class=\"dropbtn\">Configurações</a>\r\n      <div class=\"dropdown-content\">\r\n                                <a href=\"parametros.php\">Parâmetros do Sistema</a>\r\n                                <a href=\"syslog.php\">Log do Sistema</a>\r\n                                <a href=\"troca_senha.php\">Trocar Senha</a>\r\n                            </div>\r\n                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Consulta de Instrutor</h2>
            <section class="form-section">
                <h3>Buscar Instrutor</h3>
                <div class="input-group">
                    <label for="consultaInstrutorNome">Nome do Instrutor:</label>
                    <input type="text" id="consultaInstrutorNome" placeholder="Digite o nome do instrutor">
                </div>
                <div class="input-group">
                    <label for="consultaInstrutorArea">Área de Atuação:</label>
                    <select id="consultaInstrutorArea">
                        <option value="">Todas as Áreas</option>
                        </select>
                </div>
                <button onclick="consultarInstrutores()">Consultar</button>
            </section>
            <section class="list-section">
                <h3>Resultados da Consulta</h3>
                <table id="consultaInstrutoresTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Área</th>
                        </tr>
                    </thead>
                    <tbody id="consultaInstrutoresTableBody">
                        </tbody>
                </table>
                <p id="noConsultaInstrutoresMessage" style="text-align: center; display: none;">Nenhum instrutor encontrado.</p>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>