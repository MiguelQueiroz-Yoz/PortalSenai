<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NETNÚCLEO - HORTO - Recuperar Senha</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="login-page"> <div class="login-container">
        <header class="login-header">
            <div class="logo">
                <img src="logo-senai.png" alt="SESI SENAI">
            </div>
            <div class="title">NETNÚCLEO - HORTO</div>
            <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                🌙
            </button>
        </header>

        <main class="login-content">
            <h2>Recuperar Senha</h2>
            <p class="instruction-text">Por favor, informe seu e-mail ou nome de usuário para redefinir sua senha. Você receberá instruções por e-mail.</p>
            <form id="recuperarSenhaForm" action="processa_recuperacao.php" method="POST">
                <div class="input-group">
                    <label for="recoveryIdentifier">E-mail ou Usuário:</label>
                    <input type="text" id="recoveryIdentifier" name="identifier" placeholder="Seu e-mail ou nome de usuário" required>
                </div>
                <button type="submit" id="btnRecuperarSenha">Enviar Solicitação</button>
                <p id="recoveryMessage" class="info-message" style="display: none;"></p>
            </form>
            <div class="login-footer">
                <p><a href="login.php">Voltar para o Login</a></p>
            </div>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>