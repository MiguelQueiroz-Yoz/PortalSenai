<?php
require_once 'conexao.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST"]) {
    $username = $conn->real_escape_string(trim($_POST["username"]));
    $password = trim($_POST["password"]);

    $sql = "SELECT id, username, password_hash FROM usuarios WHERE username = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $username);

        if ($stmt->execute()) {
            $stmt->store_result();

            if ($stmt->num_rows == 1) {
                $stmt->bind_result($id, $db_username, $hashed_password);
                if ($stmt->fetch()) {

                    if (password_verify($password, $hashed_password)) {
                        $_SESSION["loggedin"] = true;
                        $_SESSION["id"] = $id;
                        $_SESSION["username"] = $db_username;

                        header("location: index.php");
                        exit();
                    } else {
                        $_SESSION["login_error"] = "Usuário ou senha inválidos.";
                    }
                }
            } else {
                $_SESSION["login_error"] = "Usuário ou senha inválidos.";
            }
        } else {
            $_SESSION["login_error"] = "Erro interno do servidor. Tente novamente mais tarde.";
            error_log("Erro ao executar consulta de login: " . $stmt->error);
        }

        $stmt->close();
    } else {
        $_SESSION["login_error"] = "Erro interno do servidor. Tente novamente mais tarde.";
        error_log("Erro ao preparar consulta de login: " . $conn->error);
    }

    header("location: login.php");
    exit();

} else {
    header("location: login.php");
    exit();
}

$conn->close();
?>