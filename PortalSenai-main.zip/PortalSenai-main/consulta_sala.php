<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas - Sala</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Consulta de Sala</h2>
            <section class="form-section">
                <h3>Buscar Salas</h3>
                <div class="input-group">
                    <label for="consultaSalaNome">Nome da Sala:</label>
                    <input type="text" id="consultaSalaNome" placeholder="Digite o nome da sala">
                </div>
                <div class="input-group">
                    <label for="consultaSalaCapacidadeMin">Capacidade Mínima:</label>
                    <input type="number" id="consultaSalaCapacidadeMin" min="1" placeholder="Ex: 10">
                </div>
                <button onclick="consultarSalas()">Consultar</button>
            </section>
            <section class="list-section">
                <h3>Resultados da Consulta</h3>
                <table id="consultaSalasTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome da Sala</th>
                            <th>Capacidade</th>
                        </tr>
                    </thead>
                    <tbody id="consultaSalasTableBody">
                        </tbody>
                </table>
                <p id="noConsultaSalasMessage" style="text-align: center; display: none;">Nenhuma sala encontrada.</p>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>