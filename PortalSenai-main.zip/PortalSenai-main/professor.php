<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NETNÚCLEO - HORTO - Painel do Professor</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Painel do Professor</h2>
            <section class="profile-summary">
                <h3>Olá, <span id="professorNome">Nome do Professor</span>!</h3>
                <p>Boas-vindas ao seu painel de controle.</p>
                <div class="profile-info-grid">
                    <div class="info-card">
                        <h4>Matrícula</h4>
                        <p id="professorMatricula">XXXXX</p>
                    </div>
                    <div class="info-card">
                        <h4>Área de Atuação</h4>
                        <p id="professorAreaAtuacao">Tecnologia</p>
                    </div>
                    <div class="info-card">
                        <h4>Status</h4>
                        <p id="professorStatus">Ativo</p>
                    </div>
                </div>
            </section>

            <section class="professor-dashboard-sections">
                <h3>Ações Rápidas</h3>
                <div class="quick-actions-grid">
                    <a href="materias_a_lancar.php" class="action-card">
                        <i class="fas fa-pencil-alt"></i>
                        <h4>Lançar Aulas/Atividades</h4>
                        <p>Gerencie suas pendências de lançamento.</p>
                    </a>
                    <a href="consulta_horario.php" class="action-card">
                        <i class="fas fa-calendar-alt"></i>
                        <h4>Meu Horário</h4>
                        <p>Consulte sua grade de aulas.</p>
                    </a>
                    <a href="consulta_turma.php" class="action-card"> <i class="fas fa-users"></i>
                        <h4>Minhas Turmas</h4>
                        <p>Veja detalhes e alunos das suas turmas.</p>
                    </a>
                    <a href="alterar_senha.php" class="action-card"> <i class="fas fa-key"></i>
                        <h4>Alterar Senha</h4>
                        <p>Mantenha sua conta segura.</p>
                    </a>
                </div>
            </section>

            </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>