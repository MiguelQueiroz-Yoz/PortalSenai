<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NETNÚCLEO - HORTO - Cadastro de Usuário</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="login-page">
    <div class="login-container">
        <header class="login-header">
            <div class="logo">
                <img src="logo-senai.png" alt="SESI SENAI">
            </div>
            <div class="title">NETNÚCLEO - HORTO</div>
            <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                🌙
            </button>
        </header>

        <main class="login-content">
            <h2>Cadastro de Novo Usuário</h2>
            <form id="cadastroForm" action="processa_cadastro.php" method="POST">
                <div class="input-group">
                    <label for="nomeCompleto">Nome Completo:</label>
                    <input type="text" id="nomeCompleto" name="nomeCompleto" placeholder="Seu nome completo" required>
                </div>
                <div class="input-group">
                    <label for="emailCadastro">E-mail:</label>
                    <input type="email" id="emailCadastro" name="email" placeholder="seu@email.com" required>
                </div>
                <div class="input-group">
                    <label for="usernameCadastro">Usuário:</label>
                    <input type="text" id="usernameCadastro" name="username" placeholder="Nome de usuário" required>
                </div>
                <div class="input-group">
                    <label for="passwordCadastro">Senha:</label>
                    <input type="password" id="passwordCadastro" name="password" placeholder="Crie sua senha" required>
                </div>
                <div class="input-group">
                    <label for="confirmPasswordCadastro">Confirmar Senha:</label>
                    <input type="password" id="confirmPasswordCadastro" name="confirm_password" placeholder="Confirme sua senha" required>
                </div>
                <button type="submit" id="btnCadastrar">Cadastrar</button>
                <p id="cadastroMessage" class="error-message" style="display: none;"></p>
            </form>
            <div class="login-footer">
                <p>Já tem uma conta? <a href="login.php">Faça Login</a></p>
            </div>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>