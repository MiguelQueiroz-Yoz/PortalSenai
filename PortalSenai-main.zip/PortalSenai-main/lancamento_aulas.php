<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movimentação - Lançamento de Aulas</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Lançamento de Aulas</h2>
            <section class="form-section">
                <h3>Registrar Nova Aula</h3>
                <form id="lancamentoAulaForm">
                    <input type="hidden" id="aulaId" value="">
                    <div class="input-group">
                        <label for="aulaData">Data:</label>
                        <input type="date" id="aulaData" required>
                    </div>
                    <div class="input-group">
                        <label for="aulaTurma">Turma:</label>
                        <select id="aulaTurma" required>
                            <option value="">Selecione a Turma</option>
                            </select>
                    </div>
                    <div class="input-group">
                        <label for="aulaInstrutor">Instrutor:</label>
                        <select id="aulaInstrutor" required>
                            <option value="">Selecione o Instrutor</option>
                            </select>
                    </div>
                    <div class="input-group">
                        <label for="aulaMateria">Matéria:</label>
                        <select id="aulaMateria" required>
                            <option value="">Selecione a Matéria</option>
                            </select>
                    </div>
                    <div class="input-group">
                        <label for="aulaHoras">Horas/Aula:</label>
                        <input type="number" id="aulaHoras" min="0.5" step="0.5" required>
                    </div>
                    <button type="submit" id="btnRegistrarAula">Registrar Aula</button>
                    <button type="button" id="btnCancelarEdicaoAula" style="display: none;">Cancelar Edição</button>
                </form>
            </section>
            <section class="list-section">
                <h3>Aulas Lançadas Recentemente</h3>
                <div class="search-bar">
                    <input type="text" id="searchAulaInput" placeholder="Buscar aula...">
                    <button id="searchAulaButton">Buscar</button>
                </div>
                <table id="aulasTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Data</th>
                            <th>Turma</th>
                            <th>Instrutor</th>
                            <th>Matéria</th>
                            <th>Horas</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="aulasTableBody">
                        </tbody>
                </table>
                <p id="noAulasMessage" style="text-align: center; display: none;">Nenhuma aula lançada ainda.</p>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>