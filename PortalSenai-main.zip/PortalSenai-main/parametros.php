<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Parâmetros do Sistema</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="modalidades.php">Modalidades</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                                <a href="atividades.php">Atividades</a>
                                <a href="feriados.php">Feriados</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                                <a href="lancamento_atividades.php">Lançamento de Atividades</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_instrutor_calendario.php">Instrutor (Calendário)</a>
                                <a href="consulta_ocorrencias.php">Ocorrências</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="consulta_sala_calendario.php">Sala (Calendário)</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Parâmetros do Sistema</h2>
            <section class="form-section">
                <h3>Configurar Parâmetros Gerais</h3>
                <form id="parametrosForm">
                    <div class="input-group">
                        <label for="parametroNomeInstituicao">Nome da Instituição:</label>
                        <input type="text" id="parametroNomeInstituicao" placeholder="Ex: SENAI Horto" required>
                    </div>
                    <div class="input-group">
                        <label for="parametroHorasAulaPadrao">Horas-aula Padrão (minutos):</label>
                        <input type="number" id="parametroHorasAulaPadrao" min="1" placeholder="Ex: 50" required>
                    </div>
                    <div class="input-group">
                        <label for="parametroEmailContato">E-mail de Contato:</label>
                        <input type="email" id="parametroEmailContato" placeholder="contato@instituicao.com" required>
                    </div>
                    <div class="input-group">
                        <label for="parametroAtivarNotificacoes">Ativar Notificações:</label>
                        <input type="checkbox" id="parametroAtivarNotificacoes">
                    </div>
                    <button type="submit" id="btnSalvarParametros">Salvar Parâmetros</button>
                </form>
            </section>

            <section class="list-section">
                <h3>Valores Atuais dos Parâmetros</h3>
                <table id="parametrosTable">
                    <thead>
                        <tr>
                            <th>Parâmetro</th>
                            <th>Valor</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="parametrosTableBody">
                        <tr><td colspan="3" style="text-align: center;">Nenhum parâmetro configurado ainda.</td></tr>
                    </tbody>
                </table>
                <p id="noParametrosMessage" style="text-align: center; display: none;">Nenhum parâmetro registrado ainda.</p>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>