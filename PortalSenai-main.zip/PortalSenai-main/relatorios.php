<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas - Relatórios</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Geração de Relatórios</h2>
            <section class="form-section">
                <h3>Opções de Relatório</h3>
                <form id="relatorioForm">
                    <div class="input-group">
                        <label for="tipoRelatorio">Tipo de Relatório:</label>
                        <select id="tipoRelatorio" required onchange="exibirFiltrosRelatorio()">
                            <option value="">Selecione um Tipo</option>
                            <option value="aulas_lancadas">Aulas Lançadas por Período</option>
                            <option value="frequencia_turma">Frequência por Turma</option>
                            <option value="ocorrencias_instrutor">Ocorrências por Instrutor</option>
                            <option value="cargas_horarias">Cargas Horárias de Cursos</option>
                            </select>
                    </div>

                    <div id="filtrosRelatorio" style="display: none;">
                        <h4>Filtros Específicos</h4>
                        <div class="filter-group" id="filter_aulas_lancadas" style="display: none;">
                            <div class="input-group">
                                <label for="dataInicioRelatorio">Data Início:</label>
                                <input type="date" id="dataInicioRelatorio">
                            </div>
                            <div class="input-group">
                                <label for="dataFimRelatorio">Data Fim:</label>
                                <input type="date" id="dataFimRelatorio">
                            </div>
                        </div>

                        <div class="filter-group" id="filter_frequencia_turma" style="display: none;">
                            <div class="input-group">
                                <label for="relatorioTurmaSelect">Turma:</label>
                                <select id="relatorioTurmaSelect">
                                    <option value="">Selecione a Turma</option>
                                    </select>
                            </div>
                            <div class="input-group">
                                <label for="relatorioMesFrequencia">Mês/Ano:</label>
                                <input type="month" id="relatorioMesFrequencia">
                            </div>
                        </div>

                        <div class="filter-group" id="filter_ocorrencias_instrutor" style="display: none;">
                            <div class="input-group">
                                <label for="relatorioInstrutorSelect">Instrutor:</label>
                                <select id="relatorioInstrutorSelect">
                                    <option value="">Selecione o Instrutor</option>
                                    </select>
                            </div>
                            <div class="input-group">
                                <label for="relatorioAnoOcorrencia">Ano:</label>
                                <input type="number" id="relatorioAnoOcorrencia" min="2020" max="2099" value="2024">
                            </div>
                        </div>
                        </div>

                    <button type="submit" id="btnGerarRelatorio">Gerar Relatório</button>
                    <button type="button" id="btnExportarPDF" style="display: none;"><i class="fas fa-file-pdf"></i> Exportar PDF</button>
                    <button type="button" id="btnExportarExcel" style="display: none;"><i class="fas fa-file-excel"></i> Exportar Excel</button>
                </form>
            </section>

            <section class="list-section" id="areaResultadosRelatorio" style="display: none;">
                <h3>Resultados do Relatório</h3>
                <div id="conteudoRelatorio">
                    <p style="text-align: center;">Selecione um tipo de relatório e clique em "Gerar Relatório".</p>
                </div>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
    <script>
        function exibirFiltrosRelatorio() {
            const tipoRelatorio = document.getElementById('tipoRelatorio').value;
            const filtrosDiv = document.getElementById('filtrosRelatorio');
            const allFilterGroups = filtrosDiv.querySelectorAll('.filter-group');

            allFilterGroups.forEach(group => group.style.display = 'none');

            if (tipoRelatorio) {
                filtrosDiv.style.display = 'block';
                const selectedFilterGroup = document.getElementById('filter_' + tipoRelatorio);
                if (selectedFilterGroup) {
                    selectedFilterGroup.style.display = 'block';
                }
            } else {
                filtrosDiv.style.display = 'none';
            }
        }

    </script>
</body>
</html>