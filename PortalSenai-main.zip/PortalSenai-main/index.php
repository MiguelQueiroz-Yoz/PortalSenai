<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NETNÚCLEO - HORTO - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Dashboard</h2>
            <section class="dashboard-overview">
                <h3>Resumo Geral</h3>
                <div class="stats-grid">
                    <div class="stat-card">
                        <h4>Total de Turmas Ativas</h4>
                        <p id="totalTurmasAtivas">0</p>
                    </div>
                    <div class="stat-card">
                        <h4>Aulas Lançadas (Mês)</h4>
                        <p id="aulasLancadasMes">0</p>
                    </div>
                    <div class="stat-card">
                        <h4>Instrutores Cadastrados</h4>
                        <p id="instrutoresCadastrados">0</p>
                    </div>
                    <div class="stat-card">
                        <h4>Matérias Pendentes</h4>
                        <p id="materiasPendentes">0</p>
                    </div>
                </div>
            </section>

            <section class="recent-activities">
                <h3>Atividades Recentes</h3>
                <table id="recentActivitiesTable">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Tipo</th>
                            <th>Descrição</th>
                            <th>Responsável</th>
                        </tr>
                    </thead>
                    <tbody id="recentActivitiesTableBody">
                        <tr><td colspan="4" style="text-align: center;">Nenhuma atividade recente para exibir.</td></tr>
                    </tbody>
                </table>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>