function consultarSalas() {
  const nomeSala = document.getElementById('consultaSalaNome').value;
  const capacidadeMin = document.getElementById('consultaSalaCapacidadeMin').value;
  const tableBody = document.getElementById('consultaSalasTableBody');
  const noSalasMessage = document.getElementById('noConsultaSalasMessage');

  tableBody.innerHTML = '';
  noSalasMessage.style.display = 'none';

  let url = 'consulta_sala.php?fetch_data=true'; 
  if (nomeSala) {
      url += `&nome=${encodeURIComponent(nomeSala)}`;
  }
  if (capacidadeMin) {
      url += `&capacidadeMin=${encodeURIComponent(capacacidadeMin)}`;
  }

  fetch(url)
      .then(response => {
          if (!response.ok) {
              throw new Error('Erro na requisição: ' + response.statusText);
          }
          return response.json();
      })
      .then(data => {
          if (data.length > 0) {
              data.forEach(sala => {
                  const row = tableBody.insertRow();
                  row.insertCell(0).textContent = sala.id;
                  row.insertCell(1).textContent = sala.nome_sala;
                  row.insertCell(2).textContent = sala.capacidade;
              });
          } else {
              noSalasMessage.style.display = 'block';
          }
      })
      .catch(error => {
          console.error('Erro ao consultar salas:', error);
          noSalasMessage.textContent = 'Erro ao carregar salas. Tente novamente mais tarde.';
          noSalasMessage.style.display = 'block';
      });
}

document.addEventListener('DOMContentLoaded', function() {
  if (window.location.pathname.endsWith('consulta_sala.php')) {
      consultarSalas(); 
  }
});