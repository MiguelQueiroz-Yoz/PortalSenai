<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastros - Atividades</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="instrutores.php">Instrutores</a>
                                <a href="salas.php">Salas</a>
                                <a href="areas.php">Áreas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Movimentação</a>
                            <div class="dropdown-content">
                                <a href="lancamento_aulas.php">Lançamento de Aulas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horário</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                                <a href="materias_a_lancar.php">Matérias a Lançar</a>
                                <a href="materias_por_turma.php">Matérias por Turma</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>

        <main class="content center-content">
            <h2>Cadastro de Atividades</h2>
            <section class="form-section">
                <h3>Adicionar Nova Atividade</h3>
                <form id="atividadeForm">
                    <input type="hidden" id="atividadeId" value="">
                    <div class="input-group">
                        <label for="atividadeNome">Nome da Atividade:</label>
                        <input type="text" id="atividadeNome" placeholder="Ex: Projeto Final" required>
                    </div>
                    <div class="input-group">
                        <label for="atividadeDescricao">Descrição:</label>
                        <textarea id="atividadeDescricao" placeholder="Detalhes da atividade..." rows="3"></textarea>
                    </div>
                    <button type="submit" id="btnSalvarAtividade">Salvar Atividade</button>
                    <button type="button" id="btnCancelarEdicaoAtividade" style="display: none;">Cancelar Edição</button>
                </form>
            </section>
            <section class="list-section">
                <h3>Atividades Cadastradas</h3>
                <div class="search-bar">
                    <input type="text" id="searchAtividadeInput" placeholder="Buscar atividade...">
                    <button id="searchAtividadeButton">Buscar</button>
                </div>
                <table id="atividadesTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome da Atividade</th>
                            <th>Descrição</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="atividadesTableBody">
                        </tbody>
                </table>
                <p id="noAtividadesMessage" style="text-align: center; display: none;">Nenhuma atividade cadastrada ainda.</p>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>