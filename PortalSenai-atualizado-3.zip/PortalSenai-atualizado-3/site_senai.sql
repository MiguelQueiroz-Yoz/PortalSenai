-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26-Jun-2025 às 19:22
-- Versão do servidor: 10.4.6-MariaDB
-- versão do PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `site_senai`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aulas`
--

CREATE TABLE `aulas` (
  `id_aula` int(11) NOT NULL,
  `nome_turma` varchar(50) DEFAULT NULL,
  `nome_materia` varchar(100) DEFAULT NULL,
  `nome_instrutor` varchar(100) DEFAULT NULL,
  `numero_sala` varchar(50) DEFAULT NULL,
  `codigo_curso` varchar(50) DEFAULT NULL,
  `nome_curso` varchar(255) DEFAULT NULL,
  `data_aula` date NOT NULL,
  `dia_semana` varchar(20) NOT NULL,
  `periodo` varchar(20) NOT NULL,
  `tipo_aula` varchar(50) NOT NULL,
  `observacoes_aula` text DEFAULT NULL,
  `status_turma` varchar(20) NOT NULL DEFAULT 'Aberta'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `aulas`
--

INSERT INTO `aulas` (`id_aula`, `nome_turma`, `nome_materia`, `nome_instrutor`, `numero_sala`, `codigo_curso`, `nome_curso`, `data_aula`, `dia_semana`, `periodo`, `tipo_aula`, `observacoes_aula`, `status_turma`) VALUES
(1, 'HT-DIG-02-M-25', 'GC', 'SIDINEY', '217 C', 'AI-DIG-02-M', 'AI IMPRESSAO DIGITAL 2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(2, 'HT-MMA-03-M-25', 'TVA', 'KLEBER', '119 A', 'AI-MMA-03-M', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(3, 'HT-GEI-12-M-25', 'IA', 'CLAUDIO EL', '205 C', 'AI-GEI-12-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL - ARCELOMITAL', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(4, 'HT-ASS-02-M-25', 'HM', 'MILCA', '223 C', 'AI-ASS-02-M', 'ASSISTENTE DE ESTILO - 2025 (REDUZIDO)', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(5, 'HT-GEI-13-M-25', 'FL', 'PAULO EN', '107 B', 'AI-GEI-13-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(6, 'HT-MMP-01-M-25', 'MD', 'GUILHERME', '103 B', 'AI-MMP-01-M', 'APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(7, 'HT-MMA-02-M-25', 'FE', 'LEONARDO', '602 B', 'AI-MMA-02-M', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(8, 'HT-MCV-01-A-25', 'PPE', 'ROBSON F', 'GOOGLE CLASS 31', 'AI-MCV-01-A', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(9, 'HT-GEI-11-M-25', 'FQ', 'PERLA', '306 B', 'AI-GEI-11-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(10, 'HT-GEI-04-M-25', 'FQ', 'JULIANA SC', '212 C-A', 'AI-GEI-04-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(11, 'HT-GEI-10-M-25', 'FPF', 'JULIO', '702 B', 'AI-GEI-10-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(12, 'HT-GEI-11-M-25', 'FLDTM', 'MARIO SERG', '105 B', 'AI-GEI-11-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(13, 'HT-GEI-04-M-25', 'FQ', 'ALINE MAIA', '213 C-A', 'AI-GEI-04-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(14, 'HT-GEI-05-M-25', 'APFC', 'LIDIANE', '206 C', 'AI-GEI-05-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(15, 'HT-GEI-05-M-25', 'FQ', 'MARINALVA', '203 C', 'AI-GEI-05-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-16', 'SEGUNDA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(16, 'AI-MMAN-01-T-25', 'SSD', 'LEONARDO', '119 A', 'AI-MMAN-01-T-25', 'MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS - VILASA', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(17, 'AI-MCD-02-T-25', 'SSDVPF', 'VALTER', '201 B', 'AI-MCD-02-T-25', 'APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO)', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(18, 'AI-EME-02-T-25', 'ED', 'PEDRO', '303 B', 'AI-EME-02-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(19, 'AI-CPPM-01-T-25', 'PPBC', 'KAOMA', 'Oficina Calçados', 'AI-CPPM-01-T-25', 'P.E. EM CONFECCAO PRODUTOS DE MALHA', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(20, 'AI-MCV-01-T-25', 'PPE', 'ROBSON F', 'GOOGLE CLASS 31', 'AI-MCV-01-T-25', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(21, 'AI-EME-01-T-25', 'FEHP', 'CLEBER', '504 B', 'AI-EME-01-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(22, 'AI-EME-01-T-25', 'ED', 'PASCINI', '601 B', 'AI-EME-01-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(23, 'AI-EME-01-T-25', 'ISEP', 'EDMILSON', '305 B', 'AI-EME-01-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(24, 'AI-GEI-01-T-24', 'PI', 'PERLA', '215 C', 'AI-GEI-01-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(25, 'AI-GEI-14-T-24', 'FL', 'IZABELLE', '101 B', 'AI-GEI-14-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(26, 'AI-GEI-17-T-24', 'INF', 'IRIZIELAENE', '203 C', 'AI-GEI-17-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(27, 'AI-GEI-18-T-24', 'FGP', 'MARINALVA', '210 C', 'AI-GEI-18-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(28, 'AI-GEI-19-T-24', 'FGP', 'FLAVIA R', '216 C', 'AI-GEI-19-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(29, 'AI-GEI-02-T-24', 'FQ', 'JULIANA SC', '209 C', 'AI-GEI-02-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(30, 'AI-GEI-03-T-25', 'FLDTM', 'FELIX', '106 B', 'AI-GEI-03-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(31, 'AI-GEI-07-T-25', 'FLDM', 'MARIO SERG', '103 B', 'AI-GEI-07-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(32, 'AI-GEI-08-T-25', 'APFC', 'LIDIANE', '202 B', 'AI-GEI-08-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-16', 'SEGUNDA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(33, 'HT-QUA-01-N-25', 'MCP', 'LUCELIA', '204 C', 'HT-QUA-01-N-25', 'TÉCNICO EM QUALIDADE', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(34, 'HT-ELT-01-N-25', 'SED-1', 'DAVID MS', '302 B', 'HT-ELT-01-N-25', 'TÉCNICO EM ELETRÔNICA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(35, 'HT-ETT-02-N-24', 'PNI', 'RILDO WI', '105 B', 'HT-ETT-02-N-24', 'TÉCNICO EM ELETROTÉCNICA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(36, 'HT-ETT-01-N-25', 'IMEP', 'PASCINI', '304 B', 'HT-ETT-01-N-25', 'TÉCNICO EM ELETROTÉCNICA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(37, 'HT-VES-03-N-25', 'MCC', 'NEUZA MA', '224 C', 'HT-VES-03-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(38, 'HT-VES-04-N-25', 'MCC', 'ANGELO G', '223 C', 'HT-VES-04-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(39, 'HTELET-01-N-24', 'PEP-E1', 'EDMILSON', '104 B', 'HTELET-01-N-24', 'TÉCNICO EM ELETROTÉCNICA - EAD', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(40, 'HT-AUT-05-N-24', 'MVFI', 'WALFRIDO F', '602 B', 'HT-AUT-05-N-24', 'TÉCNICO DE AUTOMAÇÃO INDUSTRIAL', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(41, 'HT-MAA-03-N-24', 'GSMV', 'ARNALDO', '101 D', 'HT-MAA-03-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(42, 'HT-MAA-04-N-24', 'SFA', 'EDUARDO VA', '119 A', 'HT-MAA-04-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(43, 'HT-MAA-09-N-24', 'GSMV', 'ARNALDO', '101 D', 'HT-MAA-09-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(44, 'HT-MAA-10-N-24', 'MMV', 'FELIPE S', '117 A', 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(45, 'HT-MAA-10-N-24', 'MMV', 'IGOR SAVIN', '116 A', 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(46, 'HT-ETT-06-N-24', 'PEI', 'CLEBER', '106 B', 'HT-ETT-06-N-24', 'TÉCNICO EM ELETROTÉCNICA - 2023/2022', '2025-06-16', 'SEGUNDA', 'Noite', 'Teórica', NULL, 'Aberta'),
(47, NULL, NULL, 'WEMERSON', '112 A', NULL, NULL, '2025-06-16', 'SEGUNDA', 'Noite', 'Prática', NULL, 'Aberta'),
(48, NULL, 'AFASTAMENTO LEGAL', 'ANDERSON PEREIRA DA SILVA', NULL, NULL, 'Afastamento convocação tribunal do Júri. Autorizad...', '2025-06-16', 'SEGUNDA', 'Manhã', 'AFASTAMENTO', 'Afastamento convocação tribunal do Júri. Autorizad...', 'Aberta'),
(49, NULL, 'AFASTAMENTO LEGAL', 'ANDERSON PEREIRA DA SILVA', NULL, NULL, 'Afastamento convocação tribunal do Júri. Autorizad...', '2025-06-16', 'SEGUNDA', 'Tarde', 'AFASTAMENTO', 'Afastamento convocação tribunal do Júri. Autorizad...', 'Aberta'),
(50, 'HT-DIG-02-M-25', 'GC', 'SIDINEY', '217 C', 'AI-DIG-02-M', 'AI IMPRESSAO DIGITAL 2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(51, 'HT-MMA-03-M-25', 'TVA', 'KLEBER', '119 A', 'AI-MMA-03-M', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(52, 'AI-MCD-02-M-24', 'TF', 'JOSE MARIA', '116 A', 'AI-MCD-02-M-24', 'APRENDIZAGEM EM MECÂNICA DIESEL (REDUZIDO) - 24', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(53, 'AI-GEI-12-M-25', 'IA', 'CLAUDIO EL', '205 C', 'AI-GEI-12-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL - ARCELOMITAL', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(54, 'AI-ASS-02-M-25', 'HM', 'MILCA', '214 C', 'AI-ASS-02-M-25', 'ASSISTENTE DE ESTILO - 2025 (REDUZIDO)', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(55, 'AI-GEI-13-M-25', 'FL', 'PAULO EN', '107 B', 'AI-GEI-13-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(56, 'AI-MMP-01-M-25', 'MD', 'GUILHERME', '103 B', 'AI-MMP-01-M-25', 'APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(57, 'AI-MMA-02-M-25', 'FE', 'LEONARDO', '602 B', 'AI-MMA-02-M-25', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(58, 'AI-MCV-01-M-25', 'PPE', 'ROBSON F', 'GOOGLE CLASS 31', 'AI-MCV-01-M-25', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(59, 'AI-GEI-10-M-24', 'FPF', 'FLAVIA R', '216 C', 'AI-GEI-10-M-24', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(60, 'AI-GEI-15-M-24', 'FQ', 'PERLA', '306 B', 'AI-GEI-15-M-24', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(61, 'AI-GEI-04-M-25', 'FQ', 'JULIANA SC', '212 C-A', 'AI-GEI-04-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(62, 'AI-GEI-10-M-25', 'FPF', 'JULIO', '702 B', 'AI-GEI-10-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(63, 'AI-GEI-11-M-25', 'FLDTM', 'MARIO SERG', '105 B', 'AI-GEI-11-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(64, 'AI-GEI-04-M-25', 'FQ', 'ALINE MAIA', '213 C-A', 'AI-GEI-04-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(65, 'AI-GEI-05-M-25', 'APFC', 'LIDIANE', '209 C', 'AI-GEI-05-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(66, 'AI-GEI-05-M-25', 'FQ', 'MARINALVA', '203 C', 'AI-GEI-05-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(67, 'AI-FLG-01-M-25', 'FTC', 'MARCELO P', '215 C', 'AI-FLG-01-M-25', 'FLEXOGRAFIA 2024/2025', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(68, 'HT-IPI-001-M-24', 'DS', 'CARLOS HEN', '102 D', 'HT-IPI-001-M-24', 'TÉCNICO EM INFORMÁTICA PARA INTERNET', '2025-06-17', 'TERÇA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(69, 'AI-MMA-01-T-25', 'SSD', 'LEONARDO', '119 A', 'AI-MMA-01-T-25', 'MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS- VILASA', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(70, 'AI-MCD-03-T-25', 'SSDVPF', 'VALTER', '201 B', 'AI-MCD-03-T-25', 'APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO)', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(71, 'AI-EME-02-T-25', 'ED', 'PEDRO', '303 B', 'AI-EME-02-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(72, 'AI-MMP-01-T-25', 'MD', 'GUILHERME', '107 B', 'AI-MMP-01-T-25', 'APRENDIZAGEM MANUT. DE MAQUINAS PESADAS FLAPA 2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(73, 'AI-CPPM-01-T-25', 'PPBC', 'KAOMA', 'Oficina Calçados', 'AI-CPPM-01-T-25', 'P.E. EM CONFECCAO PRODUTOS DE MALHA', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(74, 'AI-MCV-01-T-25', 'PPE', 'ROBSON F', 'GOOGLE CLASS 31', 'AI-MCV-01-T-25', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(75, 'AI-EME-03-T-24', 'FEHP', 'CLEBER', '504 B', 'AI-EME-03-T-24', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(76, 'AI-EME-05-T-24', 'ED', 'PASCINI', '601 B', 'AI-EME-05-T-24', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(77, 'AI-EME-01-T-25', 'ISEP', 'EDMILSON', '305 B', 'AI-EME-01-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(78, 'AI-GEI-01-T-25', 'PI', 'PERLA', '215 C', 'AI-GEI-01-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(79, 'AI-GEI-16-T-24', 'FL', 'IZABELLE', '203 C', 'AI-GEI-16-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(80, 'AI-GEI-17-T-24', 'INF', 'IRIZIELAENE', '203 C', 'AI-GEI-17-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(81, 'AI-GEI-18-T-24', 'FGP', 'MARINALVA', '210 C', 'AI-GEI-18-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(82, 'AI-GEI-19-T-24', 'FGP', 'FLAVIA R', '216 C', 'AI-GEI-19-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(83, 'AI-GEI-02-T-25', 'FQ', 'JULIANA SC', '209 C', 'AI-GEI-02-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(84, 'AI-GEI-03-T-25', 'FLDTM', 'FELIX', '106 B', 'AI-GEI-03-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(85, 'AI-GEI-07-T-25', 'FLDM', 'MARIO SERG', '103 B', 'AI-GEI-07-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(86, 'AI-GEI-08-T-25', 'APFC', 'LIDIANE', '202 B', 'AI-GEI-08-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(87, 'AI-GEI-09-T-25', 'FQ', 'BETH', '208 C', 'AI-GEI-09-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-17', 'TERÇA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(88, 'HT-AUT-01-N-24', 'MVFI', 'FELIX', '508 B', 'HT-AUT-01-N-24', 'TÉCNICO DE AUTOMAÇÃO INDUSTRIAL - SP', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(89, 'HT-QUA-01-N-25', 'MCP', 'LUCELIA', '204 C', 'HT-QUA-01-N-25', 'TÉCNICO EM QUALIDADE', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(90, 'HT-ELT-01-N-25', 'SED-1', 'DAVID MS', '302 B', 'HT-ELT-01-N-25', 'TÉCNICO EM ELETRÔNICA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(91, 'HT-ETT-02-N-24', 'PNI', 'RILDO WI', '105 B', 'HT-ETT-02-N-24', 'TÉCNICO EM ELETROTÉCNICA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(92, 'HT-ETT-01-N-25', 'IMEP', 'PASCINI', '305 B', 'HT-ETT-01-N-25', 'TÉCNICO EM ELETROTÉCNICA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(93, 'HT-VES-03-N-25', 'MCC', 'NEUZA MA', '223 C', 'HT-VES-03-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(94, 'HT-VES-04-N-25', 'MCC', 'ANGELO G', '224 C', 'HT-VES-04-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(95, 'HT-AUT-05-N-24', 'MVFI', 'WALFRIDO F', '602 B', 'HT-AUT-05-N-24', 'TÉCNICO DE AUTOMAÇÃO INDUSTRIAL', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(96, 'HT-MAA-03-N-24', 'GSMV', 'ARNALDO', '101 D', 'HT-MAA-03-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(97, 'HT-MAA-04-N-24', 'SFA', 'EDUARDO VA', '119 A', 'HT-MAA-04-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(98, 'HT-MAA-09-N-24', 'GSMV', 'ARNALDO', '101 D', 'HT-MAA-09-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(99, 'HT-MAA-10-N-24', 'MMV', 'FELIPE S', '117 A', 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(100, 'HT-MAA-10-N-24', 'MMV', 'IGOR SAVIN', '116 A', 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(101, 'HT-ETT-06-N-24', 'PEI', 'CLEBER', '106 B', 'HT-ETT-06-N-24', 'TÉCNICO EM ELETROTÉCNICA - 2023/2022', '2025-06-17', 'TERÇA', 'Noite', 'Teórica', NULL, 'Aberta'),
(102, NULL, NULL, 'WEMERSON', '112 A', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(103, NULL, NULL, 'EAD 6', '104 D', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(104, NULL, NULL, 'EAD 7', '115 A', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(105, NULL, NULL, 'HERNANNY', '114 A', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(106, NULL, NULL, 'RODRIGO BE', '107 B', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(107, NULL, NULL, 'BRUNO ASS', '205 C', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(108, NULL, NULL, 'JOSÉ R', '215 C', NULL, NULL, '2025-06-17', 'TERÇA', 'Noite', 'Prática', NULL, 'Aberta'),
(109, 'AI-DIG-02-M-25', 'GC', 'SIDINEY', '217 C', 'AI-DIG-02-M-25', 'AI IMPRESSAO DIGITAL 2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(110, 'AI-MMA-03-M-25', 'TVA', 'KLEBER', '119 A', 'AI-MMA-03-M-25', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(111, 'AI-MCD-02-M-24', 'TF', 'JOSE MARIA', '116 A', 'AI-MCD-02-M-24', 'APRENDIZAGEM EM MECÂNICA DIESEL (REDUZIDO) - 24', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Encerrada'),
(112, 'AI-GEI-12-M-25', 'IA', 'CLAUDIO EL', '205 C', 'AI-GEI-12-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(113, 'AI-ASS-02-M-25', 'HM', 'MILCA', '214 C', 'AI-ASS-02-M-25', 'ASSISTENTE DE ESTILO - 2025 (REDUZIDO)', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(114, 'AI-GEI-13-M-25', 'FL', 'PAULO EN', '107 B', 'AI-GEI-13-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(115, 'AI-MMP-01-M-25', 'MD', 'GUILHERME', '103 B', 'AI-MMP-01-M-25', 'APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(116, 'AI-MMA-02-M-25', 'FE', 'LEONARDO', '602 B', 'AI-MMA-02-M-25', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(117, 'AI-MCV-01-M-25', 'PPE', 'ROBSON F', 'GOOGLE CLASS 31', 'AI-MCV-01-M-25', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(118, 'AI-GEI-11-M-24', 'FQ', 'PERLA', '306 B', 'AI-GEI-11-M-24', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(119, 'AI-GEI-04-M-25', 'FQ', 'JULIANA SC', '208 C', 'AI-GEI-04-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(120, 'AI-GEI-10-M-25', 'FPF', 'JULIO', '702 B', 'AI-GEI-10-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(121, 'AI-GEI-11-M-25', 'FLDTM', 'MARIO SERG', '105 B', 'AI-GEI-11-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(122, 'AI-GEI-04-M-25', 'FQ', 'ALINE MAIA', '212 C-A', 'AI-GEI-04-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(123, 'AI-GEI-05-M-25', 'APFC', 'LIDIANE', '209 C', 'AI-GEI-05-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(124, 'AI-GEI-05-M-25', 'APFC', 'FLAVIA R', '213 C-A', 'AI-GEI-05-M-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(125, 'AI-FLG-01-M-25', 'FTC', 'MARCELO P', '210 C', 'AI-FLG-01-M-25', 'FLEXOGRAFIA 2024/2025', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(126, 'HT-IPI-001-M-24', 'DS', 'CARLOS HEN', '102 D', 'HT-IPI-001-M-24', 'TÉCNICO EM INFORMÁTICA PARA INTERNET', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(127, 'HT-IPI-002-M-23', 'DS', 'FERNANDO L', '101 D', 'HT-IPI-002-M-23', 'TÉCNICO EM INFORMÁTICA PARA INTERNET', '2025-06-18', 'QUARTA', 'Manhã', 'Teórica', NULL, 'Aberta'),
(128, 'AI-MMA-01-T-25', 'SSD', 'LEONARDO', '119 A', 'AI-MMA-01-T-25', 'MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS- VILASA', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(129, 'AI-MCD-03-T-25', 'SSDVPF', 'VALTER', '201 B', 'AI-MCD-03-T-25', 'APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO)', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(130, 'AI-EME-02-T-25', 'ED', 'PEDRO', '303 B', 'AI-EME-02-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(131, 'AI-MMP-01-T-25', 'MD', 'GUILHERME', '107 B', 'AI-MMP-01-T-25', 'APRENDIZAGEM MANUT. DE MAQUINAS PESADAS FLAPA 2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(132, 'AI-CPPM-01-T-25', 'PPBC', 'KAOMA', 'Oficina Calçados', 'AI-CPPM-01-T-25', 'P.E. EM CONFECCAO PRODUTOS DE MALHA', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(133, 'AI-MCV-01-T-25', 'PPE', 'ROBSON F', 'GOOGLE CLASS 31', 'AI-MCV-01-T-25', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(134, 'AI-EME-03-T-24', 'FEHP', 'CLEBER', '504 B', 'AI-EME-03-T-24', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(135, 'AI-EME-05-T-24', 'ED', 'PASCINI', '601 B', 'AI-EME-05-T-24', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(136, 'AI-EME-01-T-25', 'ISEP', 'EDMILSON', '305 B', 'AI-EME-01-T-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(137, 'AI-GEI-01-T-25', 'PI', 'PERLA', '215 C', 'AI-GEI-01-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(138, 'AI-GEI-16-T-24', 'FL', 'IZABELLE', '203 C', 'AI-GEI-16-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(139, 'AI-GEI-17-T-24', 'INF', 'IRIZIELAENE', '203 C', 'AI-GEI-17-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(140, 'AI-GEI-18-T-24', 'FGP', 'BETH', '210 C', 'AI-GEI-18-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(141, 'AI-GEI-19-T-24', 'FGP', 'FLAVIA R', '216 C', 'AI-GEI-19-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(142, 'AI-GEI-02-T-25', 'FQ', 'JULIANA SC', '209 C', 'AI-GEI-02-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(143, 'AI-GEI-03-T-25', 'FLDTM', 'FELIX', '106 B', 'AI-GEI-03-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(144, 'AI-GEI-07-T-25', 'FLDM', 'MARIO SERG', '103 B', 'AI-GEI-07-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(145, 'AI-GEI-08-T-25', 'APFC', 'LIDIANE', '202 B', 'AI-GEI-08-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(146, 'AI-GEI-09-T-25', 'APFC', 'FLAVIA R', '213 C-A', 'AI-GEI-09-T-25', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025', '2025-06-18', 'QUARTA', 'Tarde', 'Teórica', NULL, 'Aberta'),
(147, 'HTELET-01-I-23', 'ISEP', 'CRISTHIAN', '603 B', 'HTELET-01-I-23', 'TÉCNICO EM ELETROTÉCNICA - PEP 23', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(148, 'HT-QUA-01-N-25', 'MCP', 'LUCELIA', '204 C', 'HT-QUA-01-N-25', 'TÉCNICO EM QUALIDADE', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(149, 'HT-ELT-01-N-25', 'SED-1', 'DAVID MS', '302 B', 'HT-ELT-01-N-25', 'TÉCNICO EM ELETRÔNICA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(150, 'HT-ETT-02-N-24', 'PNI', 'RILDO WI', '105 B', 'HT-ETT-02-N-24', 'TÉCNICO EM ELETROTÉCNICA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(151, 'HT-ETT-01-N-25', 'IMEP', 'PASCINI', '305 B', 'HT-ETT-01-N-25', 'TÉCNICO EM ELETROTÉCNICA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(152, 'HT-VES-03-N-25', 'MCC', 'NEUZA MA', '224 C', 'HT-VES-03-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(153, 'HT-VES-04-N-25', 'MCC', 'ANGELO G', '223 C', 'HT-VES-04-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(154, 'HT-AUT-05-N-24', 'MVFI', 'WALFRIDO F', '602 B', 'HT-AUT-05-N-24', 'TÉCNICO DE AUTOMAÇÃO INDUSTRIAL', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(155, 'HT-MAA-03-N-24', 'GSMV', 'ARNALDO', '101 D', 'HT-MAA-03-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(156, 'HT-MAA-04-N-24', 'SFA', 'EDUARDO VA', '119 A', 'HT-MAA-04-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(157, 'HT-MAA-09-N-24', 'GSMV', 'ARNALDO', '101 D', 'HT-MAA-09-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(158, 'HT-MAA-10-N-24', 'MMV', 'FELIPE S', '117 A', 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(159, 'HT-MAA-10-N-24', 'MMV', 'IGOR SAVIN', '116 A', 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(160, 'HT-ETT-06-N-24', 'PEI', 'CLEBER', '106 B', 'HT-ETT-06-N-24', 'TÉCNICO EM ELETROTÉCNICA - 2023/2022', '2025-06-18', 'QUARTA', 'Noite', 'Teórica', NULL, 'Aberta'),
(161, NULL, NULL, 'WEMERSON', '112 A', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta'),
(162, NULL, NULL, 'EAD 6', '104 D', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta'),
(163, NULL, NULL, 'EAD 7', '115 A', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta'),
(164, NULL, NULL, 'HERNANNY', '114 A', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta'),
(165, NULL, NULL, 'RODRIGO BE', '107 B', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta'),
(166, NULL, NULL, 'BRUNO ASS', '205 C', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta'),
(167, NULL, NULL, 'JOSÉ R', '215 C', NULL, NULL, '2025-06-18', 'QUARTA', 'Noite', 'Prática', NULL, 'Aberta');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `id_curso` int(11) NOT NULL,
  `codigo_curso` varchar(50) NOT NULL,
  `nome_curso` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`id_curso`, `codigo_curso`, `nome_curso`) VALUES
(1, 'AI-DIG-02-M', 'A.I IMPRESSAO DIGITAL 2025'),
(2, 'AI-MMA-03-M', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA'),
(3, 'AI-GEI-12-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL - ARCELOMITAL'),
(4, 'AI-ASS-02-M', 'ASSISTENTE DE ESTILO - 2025 (REDUZIDO)'),
(5, 'AI-GEI-13-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT'),
(6, 'AI-MMP-01-M', 'APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025'),
(7, 'AI-MMA-02-M', 'A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS'),
(8, 'AI-MCV-01-A', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025'),
(9, 'AI-GEI-11-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025'),
(10, 'AI-GEI-04-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025'),
(11, 'AI-GEI-10-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025'),
(12, 'AI-GEI-05-M', 'APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025'),
(13, 'AI-MMA-01-M', 'MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS - VILASA'),
(14, 'AI-MCD-02-M', 'APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO)'),
(15, 'AI-EME-02-M', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA'),
(16, 'AI-ASS-01-M', 'ASSISTENTE DE ESTILO - 2025 (REDUZIDO)'),
(17, 'AI-CPPM-01-M', 'P.E. EM CONFECCAO PRODUTOS DE MALHA'),
(18, 'AI-MCV-01-M', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025'),
(19, 'AI-EME-01-M', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA'),
(20, 'AI-GEI-01-M', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(21, 'AI-GEI-14-M', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(22, 'AI-GEI-17-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(23, 'AI-GEI-18-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(24, 'AI-GEI-19-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(25, 'AI-GEI-02-T-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(26, 'AI-GEI-03-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(27, 'AI-GEI-07-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025'),
(28, 'AI-GEI-08-T-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025'),
(29, 'AI-FLG-01-M', 'APRENDIZAGEM IMPRESSAO GRAFICA'),
(30, 'HT-QUA-01-N-25', 'TÉCNICO EM QUALIDADE'),
(31, 'HT-ELT-01-N-25', 'TÉCNICO EM ELETRÔNICA'),
(32, 'HT-ETT-02-N-24', 'TÉCNICO EM ELETROTÉCNICA'),
(33, 'HT-ETT-01-N-25', 'TÉCNICO EM ELETROTÉCNICA'),
(34, 'HT-VES-03-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5'),
(35, 'HT-VES-04-N-25', 'TÉCNICO EM VESTUÁRIO - TF 5'),
(36, 'HTELET-01-N-24', 'TÉCNICO EM ELETROTÉCNICA - EAD'),
(37, 'HT-AUT-05-N-24', 'TÉCNICO DE AUTOMAÇÃO INDUSTRIAL'),
(38, 'HT-MAA-03-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA'),
(39, 'HT-MAA-04-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA'),
(40, 'HT-MAA-09-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA'),
(41, 'HT-MAA-10-N-24', 'TÉCNICO DE MANUTENÇÃO AUTOMOTIVA'),
(42, 'HT-ETT-06-N-24', 'TÉCNICO EM ELETROTÉCNICA - 2023/2022'),
(43, 'AI-DIG-02-M-25', 'AI IMPRESSAO DIGITAL 2025'),
(44, 'AI-MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA', 'AI MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA'),
(45, 'AI-GEI-12-M-25', 'APRENDIZAGEM EM GESTAO - ARCELOMITAL'),
(46, 'AI-ASS-01-M-25', 'ASSISTENTE DE ESTILO - 2025 (REDUZIDO)'),
(47, 'AI-EME-02-M-25', 'ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA'),
(48, 'AI-MCD-01-M-25', 'APRENDIZAGEM MA NUT DE MAQUINAS PESADAS FLAPA 2025'),
(49, 'AI-MCV-01-M-25', 'MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025'),
(50, 'AI-GEI-01-M-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(51, 'AI-GEI-11-M-24', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(52, 'AI-GEI-10-M-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(53, 'AI-GEI-02-M-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025'),
(54, 'AI-GEI-06-M-25', 'APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025'),
(55, 'AI-FLG-03-M-25', 'APRENDIZAGEM IMPRESSAO GRAFICA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `horario_instrutor_consulta`
--

CREATE TABLE `horario_instrutor_consulta` (
  `id_horario_instrutor_consulta` int(11) NOT NULL,
  `id_instrutor` int(11) DEFAULT NULL,
  `data_aula` date DEFAULT NULL,
  `dia_semana` varchar(20) DEFAULT NULL,
  `periodo` varchar(20) DEFAULT NULL,
  `id_aula` int(11) DEFAULT NULL,
  `status_aula` varchar(50) DEFAULT NULL,
  `observacoes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `horario_instrutor_consulta`
--

INSERT INTO `horario_instrutor_consulta` (`id_horario_instrutor_consulta`, `id_instrutor`, `data_aula`, `dia_semana`, `periodo`, `id_aula`, `status_aula`, `observacoes`) VALUES
(1, 7, '2025-06-16', 'SEGUNDA', 'Tarde', 16, 'Teórica', NULL),
(2, 16, '2025-06-16', 'SEGUNDA', 'Tarde', 17, 'Teórica', NULL),
(3, 17, '2025-06-16', 'SEGUNDA', 'Tarde', 18, 'Teórica', NULL),
(4, 18, '2025-06-16', 'SEGUNDA', 'Tarde', 19, 'Teórica', NULL),
(5, 8, '2025-06-16', 'SEGUNDA', 'Tarde', 20, 'Teórica', NULL),
(6, 19, '2025-06-16', 'SEGUNDA', 'Tarde', 21, 'Teórica', NULL),
(7, 20, '2025-06-16', 'SEGUNDA', 'Tarde', 22, 'Teórica', NULL),
(8, 21, '2025-06-16', 'SEGUNDA', 'Tarde', 23, 'Teórica', NULL),
(9, 9, '2025-06-16', 'SEGUNDA', 'Tarde', 24, 'Teórica', NULL),
(10, 45, '2025-06-16', 'SEGUNDA', 'Tarde', 25, 'Teórica', NULL),
(11, 22, '2025-06-16', 'SEGUNDA', 'Tarde', 26, 'Teórica', NULL),
(12, 15, '2025-06-16', 'SEGUNDA', 'Tarde', 27, 'Teórica', NULL),
(13, 24, '2025-06-16', 'SEGUNDA', 'Tarde', 28, 'Teórica', NULL),
(14, 10, '2025-06-16', 'SEGUNDA', 'Tarde', 29, 'Teórica', NULL),
(15, 23, '2025-06-16', 'SEGUNDA', 'Tarde', 30, 'Teórica', NULL),
(16, 12, '2025-06-16', 'SEGUNDA', 'Tarde', 31, 'Teórica', NULL),
(17, 14, '2025-06-16', 'SEGUNDA', 'Tarde', 32, 'Teórica', NULL),
(18, 25, '2025-06-16', 'SEGUNDA', 'Noite', 33, 'Teórica', NULL),
(19, 26, '2025-06-16', 'SEGUNDA', 'Noite', 34, 'Teórica', NULL),
(20, 27, '2025-06-16', 'SEGUNDA', 'Noite', 35, 'Teórica', NULL),
(21, 20, '2025-06-16', 'SEGUNDA', 'Noite', 36, 'Teórica', NULL),
(22, 28, '2025-06-16', 'SEGUNDA', 'Noite', 37, 'Teórica', NULL),
(23, 29, '2025-06-16', 'SEGUNDA', 'Noite', 38, 'Teórica', NULL),
(24, 21, '2025-06-16', 'SEGUNDA', 'Noite', 39, 'Teórica', NULL),
(25, 30, '2025-06-16', 'SEGUNDA', 'Noite', 40, 'Teórica', NULL),
(26, 31, '2025-06-16', 'SEGUNDA', 'Noite', 41, 'Teórica', NULL),
(27, 32, '2025-06-16', 'SEGUNDA', 'Noite', 42, 'Teórica', NULL),
(28, 31, '2025-06-16', 'SEGUNDA', 'Noite', 43, 'Teórica', NULL),
(29, 33, '2025-06-16', 'SEGUNDA', 'Noite', 44, 'Teórica', NULL),
(30, 34, '2025-06-16', 'SEGUNDA', 'Noite', 45, 'Teórica', NULL),
(31, 19, '2025-06-16', 'SEGUNDA', 'Noite', 46, 'Teórica', NULL),
(32, 35, '2025-06-16', 'SEGUNDA', 'Noite', 47, 'Prática', NULL),
(33, 36, '2025-06-16', 'SEGUNDA', 'Manhã', 48, 'AFASTAMENTO', 'Afastamento convocação tribunal do Júri. Autorizad...'),
(34, 36, '2025-06-16', 'SEGUNDA', 'Tarde', 49, 'AFASTAMENTO', 'Afastamento convocação tribunal do Júri. Autorizad...'),
(35, 7, '2025-06-17', 'TERÇA', 'Tarde', 69, 'Teórica', NULL),
(36, 16, '2025-06-17', 'TERÇA', 'Tarde', 70, 'Teórica', NULL),
(37, 17, '2025-06-17', 'TERÇA', 'Tarde', 71, 'Teórica', NULL),
(38, 6, '2025-06-17', 'TERÇA', 'Tarde', 72, 'Teórica', NULL),
(39, 18, '2025-06-17', 'TERÇA', 'Tarde', 73, 'Teórica', NULL),
(40, 8, '2025-06-17', 'TERÇA', 'Tarde', 74, 'Teórica', NULL),
(41, 19, '2025-06-17', 'TERÇA', 'Tarde', 75, 'Teórica', NULL),
(42, 20, '2025-06-17', 'TERÇA', 'Tarde', 76, 'Teórica', NULL),
(43, 21, '2025-06-17', 'TERÇA', 'Tarde', 77, 'Teórica', NULL),
(44, 9, '2025-06-17', 'TERÇA', 'Tarde', 78, 'Teórica', NULL),
(45, 45, '2025-06-17', 'TERÇA', 'Tarde', 79, 'Teórica', NULL),
(46, 22, '2025-06-17', 'TERÇA', 'Tarde', 80, 'Teórica', NULL),
(47, 15, '2025-06-17', 'TERÇA', 'Tarde', 81, 'Teórica', NULL),
(48, 24, '2025-06-17', 'TERÇA', 'Tarde', 82, 'Teórica', NULL),
(49, 10, '2025-06-17', 'TERÇA', 'Tarde', 83, 'Teórica', NULL),
(50, 23, '2025-06-17', 'TERÇA', 'Tarde', 84, 'Teórica', NULL),
(51, 12, '2025-06-17', 'TERÇA', 'Tarde', 85, 'Teórica', NULL),
(52, 14, '2025-06-17', 'TERÇA', 'Tarde', 86, 'Teórica', NULL),
(53, 44, '2025-06-17', 'TERÇA', 'Tarde', 87, 'Teórica', NULL),
(54, 23, '2025-06-17', 'TERÇA', 'Noite', 88, 'Teórica', NULL),
(55, 25, '2025-06-17', 'TERÇA', 'Noite', 89, 'Teórica', NULL),
(56, 26, '2025-06-17', 'TERÇA', 'Noite', 90, 'Teórica', NULL),
(57, 27, '2025-06-17', 'TERÇA', 'Noite', 91, 'Teórica', NULL),
(58, 20, '2025-06-17', 'TERÇA', 'Noite', 92, 'Teórica', NULL),
(59, 28, '2025-06-17', 'TERÇA', 'Noite', 93, 'Teórica', NULL),
(60, 29, '2025-06-17', 'TERÇA', 'Noite', 94, 'Teórica', NULL),
(61, 30, '2025-06-17', 'TERÇA', 'Noite', 95, 'Teórica', NULL),
(62, 31, '2025-06-17', 'TERÇA', 'Noite', 96, 'Teórica', NULL),
(63, 32, '2025-06-17', 'TERÇA', 'Noite', 97, 'Teórica', NULL),
(64, 31, '2025-06-17', 'TERÇA', 'Noite', 98, 'Teórica', NULL),
(65, 33, '2025-06-17', 'TERÇA', 'Noite', 99, 'Teórica', NULL),
(66, 34, '2025-06-17', 'TERÇA', 'Noite', 100, 'Teórica', NULL),
(67, 19, '2025-06-17', 'TERÇA', 'Noite', 101, 'Teórica', NULL),
(68, 35, '2025-06-17', 'TERÇA', 'Noite', 102, 'Prática', NULL),
(69, 48, '2025-06-17', 'TERÇA', 'Noite', 103, 'Prática', NULL),
(70, 49, '2025-06-17', 'TERÇA', 'Noite', 104, 'Prática', NULL),
(71, 39, '2025-06-17', 'TERÇA', 'Noite', 105, 'Prática', NULL),
(72, 40, '2025-06-17', 'TERÇA', 'Noite', 106, 'Prática', NULL),
(73, 41, '2025-06-17', 'TERÇA', 'Noite', 107, 'Prática', NULL),
(74, 42, '2025-06-17', 'TERÇA', 'Noite', 108, 'Prática', NULL),
(75, 7, '2025-06-18', 'QUARTA', 'Tarde', 128, 'Teórica', NULL),
(76, 16, '2025-06-18', 'QUARTA', 'Tarde', 129, 'Teórica', NULL),
(77, 17, '2025-06-18', 'QUARTA', 'Tarde', 130, 'Teórica', NULL),
(78, 6, '2025-06-18', 'QUARTA', 'Tarde', 131, 'Teórica', NULL),
(79, 18, '2025-06-18', 'QUARTA', 'Tarde', 132, 'Teórica', NULL),
(80, 8, '2025-06-18', 'QUARTA', 'Tarde', 133, 'Teórica', NULL),
(81, 19, '2025-06-18', 'QUARTA', 'Tarde', 134, 'Teórica', NULL),
(82, 20, '2025-06-18', 'QUARTA', 'Tarde', 135, 'Teórica', NULL),
(83, 21, '2025-06-18', 'QUARTA', 'Tarde', 136, 'Teórica', NULL),
(84, 9, '2025-06-18', 'QUARTA', 'Tarde', 137, 'Teórica', NULL),
(85, 45, '2025-06-18', 'QUARTA', 'Tarde', 138, 'Teórica', NULL),
(86, 22, '2025-06-18', 'QUARTA', 'Tarde', 139, 'Teórica', NULL),
(87, 44, '2025-06-18', 'QUARTA', 'Tarde', 140, 'Teórica', NULL),
(88, 24, '2025-06-18', 'QUARTA', 'Tarde', 141, 'Teórica', NULL),
(89, 10, '2025-06-18', 'QUARTA', 'Tarde', 142, 'Teórica', NULL),
(90, 23, '2025-06-18', 'QUARTA', 'Tarde', 143, 'Teórica', NULL),
(91, 12, '2025-06-18', 'QUARTA', 'Tarde', 144, 'Teórica', NULL),
(92, 14, '2025-06-18', 'QUARTA', 'Tarde', 145, 'Teórica', NULL),
(93, 24, '2025-06-18', 'QUARTA', 'Tarde', 146, 'Teórica', NULL),
(94, 38, '2025-06-18', 'QUARTA', 'Noite', 147, 'Teórica', NULL),
(95, 25, '2025-06-18', 'QUARTA', 'Noite', 148, 'Teórica', NULL),
(96, 26, '2025-06-18', 'QUARTA', 'Noite', 149, 'Teórica', NULL),
(97, 27, '2025-06-18', 'QUARTA', 'Noite', 150, 'Teórica', NULL),
(98, 20, '2025-06-18', 'QUARTA', 'Noite', 151, 'Teórica', NULL),
(99, 28, '2025-06-18', 'QUARTA', 'Noite', 152, 'Teórica', NULL),
(100, 29, '2025-06-18', 'QUARTA', 'Noite', 153, 'Teórica', NULL),
(101, 30, '2025-06-18', 'QUARTA', 'Noite', 154, 'Teórica', NULL),
(102, 31, '2025-06-18', 'QUARTA', 'Noite', 155, 'Teórica', NULL),
(103, 32, '2025-06-18', 'QUARTA', 'Noite', 156, 'Teórica', NULL),
(104, 31, '2025-06-18', 'QUARTA', 'Noite', 157, 'Teórica', NULL),
(105, 33, '2025-06-18', 'QUARTA', 'Noite', 158, 'Teórica', NULL),
(106, 34, '2025-06-18', 'QUARTA', 'Noite', 159, 'Teórica', NULL),
(107, 19, '2025-06-18', 'QUARTA', 'Noite', 160, 'Teórica', NULL),
(108, 35, '2025-06-18', 'QUARTA', 'Noite', 161, 'Prática', NULL),
(109, 48, '2025-06-18', 'QUARTA', 'Noite', 162, 'Prática', NULL),
(110, 49, '2025-06-18', 'QUARTA', 'Noite', 163, 'Prática', NULL),
(111, 39, '2025-06-18', 'QUARTA', 'Noite', 164, 'Prática', NULL),
(112, 40, '2025-06-18', 'QUARTA', 'Noite', 165, 'Prática', NULL),
(113, 41, '2025-06-18', 'QUARTA', 'Noite', 166, 'Prática', NULL),
(114, 42, '2025-06-18', 'QUARTA', 'Noite', 167, 'Prática', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `horario_sala_consulta`
--

CREATE TABLE `horario_sala_consulta` (
  `id_horario_sala_consulta` int(11) NOT NULL,
  `numero_sala` varchar(50) DEFAULT NULL,
  `data_aula` date DEFAULT NULL,
  `dia_semana` varchar(20) DEFAULT NULL,
  `periodo` varchar(20) DEFAULT NULL,
  `id_aula` int(11) DEFAULT NULL,
  `status_ocupacao` varchar(50) DEFAULT NULL,
  `descricao_evento` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `horario_sala_consulta`
--

INSERT INTO `horario_sala_consulta` (`id_horario_sala_consulta`, `numero_sala`, `data_aula`, `dia_semana`, `periodo`, `id_aula`, `status_ocupacao`, `descricao_evento`) VALUES
(1, '217 C', '2025-06-16', 'SEGUNDA', 'Manhã', 1, 'Ocupada', 'GC - AI IMPRESSAO DIGITAL 2025 (Prof. SIDINEY)'),
(2, '119 A', '2025-06-16', 'SEGUNDA', 'Manhã', 2, 'Ocupada', 'TVA - A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA (Prof. KLEBER)'),
(3, '205 C', '2025-06-16', 'SEGUNDA', 'Manhã', 3, 'Ocupada', 'IA - APRENDIZAGEM EM GESTAO INDUSTRIAL - ARCELOMITAL (Prof. CLAUDIO EL)'),
(4, '223 C', '2025-06-16', 'SEGUNDA', 'Manhã', 4, 'Ocupada', 'HM - ASSISTENTE DE ESTILO - 2025 (REDUZIDO) (Prof. MILCA)'),
(5, '107 B', '2025-06-16', 'SEGUNDA', 'Manhã', 5, 'Ocupada', 'FL - APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT (Prof. PAULO EN)'),
(6, '103 B', '2025-06-16', 'SEGUNDA', 'Manhã', 6, 'Ocupada', 'MD - APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025 (Prof. GUILHERME)'),
(7, '602 B', '2025-06-16', 'SEGUNDA', 'Manhã', 7, 'Ocupada', 'FE - A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS (Prof. LEONARDO)'),
(8, 'GOOGLE CLASS 31', '2025-06-16', 'SEGUNDA', 'Manhã', 8, 'Ocupada', 'PPE - MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025 (Prof. ROBSON F)'),
(9, '306 B', '2025-06-16', 'SEGUNDA', 'Manhã', 9, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. PERLA)'),
(10, '212 C-A', '2025-06-16', 'SEGUNDA', 'Manhã', 10, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. JULIANA SC)'),
(11, '702 B', '2025-06-16', 'SEGUNDA', 'Manhã', 11, 'Ocupada', 'FPF - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. JULIO)'),
(12, '105 B', '2025-06-16', 'SEGUNDA', 'Manhã', 12, 'Ocupada', 'FLDTM - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. MARIO SERG)'),
(13, '213 C-A', '2025-06-16', 'SEGUNDA', 'Manhã', 13, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. ALINE MAIA)'),
(14, '206 C', '2025-06-16', 'SEGUNDA', 'Manhã', 14, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. LIDIANE)'),
(15, '203 C', '2025-06-16', 'SEGUNDA', 'Manhã', 15, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. MARINALVA)'),
(16, '119 A', '2025-06-16', 'SEGUNDA', 'Tarde', 16, 'Ocupada', 'SSD - MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS - VILASA (Prof. LEONARDO)'),
(17, '201 B', '2025-06-16', 'SEGUNDA', 'Tarde', 17, 'Ocupada', 'SSDVPF - APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO) (Prof. VALTER)'),
(18, '303 B', '2025-06-16', 'SEGUNDA', 'Tarde', 18, 'Ocupada', 'ED - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. PEDRO)'),
(19, 'Oficina Calçados', '2025-06-16', 'SEGUNDA', 'Tarde', 19, 'Ocupada', 'PPBC - P.E. EM CONFECCAO PRODUTOS DE MALHA (Prof. KAOMA)'),
(20, 'GOOGLE CLASS 31', '2025-06-16', 'SEGUNDA', 'Tarde', 20, 'Ocupada', 'PPE - MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025 (Prof. ROBSON F)'),
(21, '504 B', '2025-06-16', 'SEGUNDA', 'Tarde', 21, 'Ocupada', 'FEHP - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. CLEBER)'),
(22, '601 B', '2025-06-16', 'SEGUNDA', 'Tarde', 22, 'Ocupada', 'ED - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. PASCINI)'),
(23, '305 B', '2025-06-16', 'SEGUNDA', 'Tarde', 23, 'Ocupada', 'ISEP - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. EDMILSON)'),
(24, '215 C', '2025-06-16', 'SEGUNDA', 'Tarde', 24, 'Ocupada', 'PI - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. PERLA)'),
(25, '101 B', '2025-06-16', 'SEGUNDA', 'Tarde', 25, 'Ocupada', 'FL - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. IZABELLE)'),
(26, '203 C', '2025-06-16', 'SEGUNDA', 'Tarde', 26, 'Ocupada', 'INF - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. IRIZIELAENE)'),
(27, '210 C', '2025-06-16', 'SEGUNDA', 'Tarde', 27, 'Ocupada', 'FGP - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. MARINALVA)'),
(28, '216 C', '2025-06-16', 'SEGUNDA', 'Tarde', 28, 'Ocupada', 'FGP - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. FLAVIA R)'),
(29, '209 C', '2025-06-16', 'SEGUNDA', 'Tarde', 29, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. JULIANA SC)'),
(30, '106 B', '2025-06-16', 'SEGUNDA', 'Tarde', 30, 'Ocupada', 'FLDTM - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. FELIX)'),
(31, '103 B', '2025-06-16', 'SEGUNDA', 'Tarde', 31, 'Ocupada', 'FLDM - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. MARIO SERG)'),
(32, '202 B', '2025-06-16', 'SEGUNDA', 'Tarde', 32, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. LIDIANE)'),
(33, '204 C', '2025-06-16', 'SEGUNDA', 'Noite', 33, 'Ocupada', 'MCP - TÉCNICO EM QUALIDADE (Prof. LUCELIA)'),
(34, '302 B', '2025-06-16', 'SEGUNDA', 'Noite', 34, 'Ocupada', 'SED-1 - TÉCNICO EM ELETRÔNICA (Prof. DAVID MS)'),
(35, '105 B', '2025-06-16', 'SEGUNDA', 'Noite', 35, 'Ocupada', 'PNI - TÉCNICO EM ELETROTÉCNICA (Prof. RILDO WI)'),
(36, '304 B', '2025-06-16', 'SEGUNDA', 'Noite', 36, 'Ocupada', 'IMEP - TÉCNICO EM ELETROTÉCNICA (Prof. PASCINI)'),
(37, '224 C', '2025-06-16', 'SEGUNDA', 'Noite', 37, 'Ocupada', 'MCC - TÉCNICO EM VESTUÁRIO - TF 5 (Prof. NEUZA MA)'),
(38, '223 C', '2025-06-16', 'SEGUNDA', 'Noite', 38, 'Ocupada', 'MCC - TÉCNICO EM VESTUÁRIO - TF 5 (Prof. ANGELO G)'),
(39, '104 B', '2025-06-16', 'SEGUNDA', 'Noite', 39, 'Ocupada', 'PEP-E1 - TÉCNICO EM ELETROTÉCNICA - EAD (Prof. EDMILSON)'),
(40, '602 B', '2025-06-16', 'SEGUNDA', 'Noite', 40, 'Ocupada', 'MVFI - TÉCNICO DE AUTOMAÇÃO INDUSTRIAL (Prof. WALFRIDO F)'),
(41, '101 D', '2025-06-16', 'SEGUNDA', 'Noite', 41, 'Ocupada', 'GSMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. ARNALDO)'),
(42, '119 A', '2025-06-16', 'SEGUNDA', 'Noite', 42, 'Ocupada', 'SFA - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. EDUARDO VA)'),
(43, '101 D', '2025-06-16', 'SEGUNDA', 'Noite', 43, 'Ocupada', 'GSMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. ARNALDO)'),
(44, '117 A', '2025-06-16', 'SEGUNDA', 'Noite', 44, 'Ocupada', 'MMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. FELIPE S)'),
(45, '116 A', '2025-06-16', 'SEGUNDA', 'Noite', 45, 'Ocupada', 'MMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. IGOR SAVIN)'),
(46, '106 B', '2025-06-16', 'SEGUNDA', 'Noite', 46, 'Ocupada', 'PEI - TÉCNICO EM ELETROTÉCNICA - 2023/2022 (Prof. CLEBER)'),
(47, '112 A', '2025-06-16', 'SEGUNDA', 'Noite', 47, 'Ocupada', NULL),
(48, '217 C', '2025-06-17', 'TERÇA', 'Manhã', 50, 'Ocupada', 'GC - AI IMPRESSAO DIGITAL 2025 (Prof. SIDINEY)'),
(49, '119 A', '2025-06-17', 'TERÇA', 'Manhã', 51, 'Ocupada', 'TVA - A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA (Prof. KLEBER)'),
(50, '116 A', '2025-06-17', 'TERÇA', 'Manhã', 52, 'Ocupada', 'TF - APRENDIZAGEM EM MECÂNICA DIESEL (REDUZIDO) - 24 (Prof. JOSE MARIA)'),
(51, '205 C', '2025-06-17', 'TERÇA', 'Manhã', 53, 'Ocupada', 'IA - APRENDIZAGEM EM GESTAO INDUSTRIAL - ARCELOMITAL (Prof. CLAUDIO EL)'),
(52, '214 C', '2025-06-17', 'TERÇA', 'Manhã', 54, 'Ocupada', 'HM - ASSISTENTE DE ESTILO - 2025 (REDUZIDO) (Prof. MILCA)'),
(53, '107 B', '2025-06-17', 'TERÇA', 'Manhã', 55, 'Ocupada', 'FL - APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT (Prof. PAULO EN)'),
(54, '103 B', '2025-06-17', 'TERÇA', 'Manhã', 56, 'Ocupada', 'MD - APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025 (Prof. GUILHERME)'),
(55, '602 B', '2025-06-17', 'TERÇA', 'Manhã', 57, 'Ocupada', 'FE - A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS (Prof. LEONARDO)'),
(56, 'GOOGLE CLASS 31', '2025-06-17', 'TERÇA', 'Manhã', 58, 'Ocupada', 'PPE - MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025 (Prof. ROBSON F)'),
(57, '216 C', '2025-06-17', 'TERÇA', 'Manhã', 59, 'Ocupada', 'FPF - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. FLAVIA R)'),
(58, '306 B', '2025-06-17', 'TERÇA', 'Manhã', 60, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. PERLA)'),
(59, '212 C-A', '2025-06-17', 'TERÇA', 'Manhã', 61, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. JULIANA SC)'),
(60, '702 B', '2025-06-17', 'TERÇA', 'Manhã', 62, 'Ocupada', 'FPF - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. JULIO)'),
(61, '105 B', '2025-06-17', 'TERÇA', 'Manhã', 63, 'Ocupada', 'FLDTM - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. MARIO SERG)'),
(62, '213 C-A', '2025-06-17', 'TERÇA', 'Manhã', 64, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. ALINE MAIA)'),
(63, '209 C', '2025-06-17', 'TERÇA', 'Manhã', 65, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. LIDIANE)'),
(64, '203 C', '2025-06-17', 'TERÇA', 'Manhã', 66, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. MARINALVA)'),
(65, '215 C', '2025-06-17', 'TERÇA', 'Manhã', 67, 'Ocupada', 'FTC - FLEXOGRAFIA 2024/2025 (Prof. MARCELO P)'),
(66, '102 D', '2025-06-17', 'TERÇA', 'Manhã', 68, 'Ocupada', 'DS - TÉCNICO EM INFORMÁTICA PARA INTERNET (Prof. CARLOS HEN)'),
(67, '119 A', '2025-06-17', 'TERÇA', 'Tarde', 69, 'Ocupada', 'SSD - MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS- VILASA (Prof. LEONARDO)'),
(68, '201 B', '2025-06-17', 'TERÇA', 'Tarde', 70, 'Ocupada', 'SSDVPF - APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO) (Prof. VALTER)'),
(69, '303 B', '2025-06-17', 'TERÇA', 'Tarde', 71, 'Ocupada', 'ED - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. PEDRO)'),
(70, '107 B', '2025-06-17', 'TERÇA', 'Tarde', 72, 'Ocupada', 'MD - APRENDIZAGEM MANUT. DE MAQUINAS PESADAS FLAPA 2025 (Prof. GUILHERME)'),
(71, 'Oficina Calçados', '2025-06-17', 'TERÇA', 'Tarde', 73, 'Ocupada', 'PPBC - P.E. EM CONFECCAO PRODUTOS DE MALHA (Prof. KAOMA)'),
(72, 'GOOGLE CLASS 31', '2025-06-17', 'TERÇA', 'Tarde', 74, 'Ocupada', 'PPE - MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025 (Prof. ROBSON F)'),
(73, '504 B', '2025-06-17', 'TERÇA', 'Tarde', 75, 'Ocupada', 'FEHP - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. CLEBER)'),
(74, '601 B', '2025-06-17', 'TERÇA', 'Tarde', 76, 'Ocupada', 'ED - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. PASCINI)'),
(75, '305 B', '2025-06-17', 'TERÇA', 'Tarde', 77, 'Ocupada', 'ISEP - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. EDMILSON)'),
(76, '215 C', '2025-06-17', 'TERÇA', 'Tarde', 78, 'Ocupada', 'PI - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. PERLA)'),
(77, '203 C', '2025-06-17', 'TERÇA', 'Tarde', 79, 'Ocupada', 'FL - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. IZABELLE)'),
(78, '203 C', '2025-06-17', 'TERÇA', 'Tarde', 80, 'Ocupada', 'INF - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. IRIZIELAENE)'),
(79, '210 C', '2025-06-17', 'TERÇA', 'Tarde', 81, 'Ocupada', 'FGP - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. MARINALVA)'),
(80, '216 C', '2025-06-17', 'TERÇA', 'Tarde', 82, 'Ocupada', 'FGP - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. FLAVIA R)'),
(81, '209 C', '2025-06-17', 'TERÇA', 'Tarde', 83, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. JULIANA SC)'),
(82, '106 B', '2025-06-17', 'TERÇA', 'Tarde', 84, 'Ocupada', 'FLDTM - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. FELIX)'),
(83, '103 B', '2025-06-17', 'TERÇA', 'Tarde', 85, 'Ocupada', 'FLDM - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. MARIO SERG)'),
(84, '202 B', '2025-06-17', 'TERÇA', 'Tarde', 86, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. LIDIANE)'),
(85, '208 C', '2025-06-17', 'TERÇA', 'Tarde', 87, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. BETH)'),
(86, '508 B', '2025-06-17', 'TERÇA', 'Noite', 88, 'Ocupada', 'MVFI - TÉCNICO DE AUTOMAÇÃO INDUSTRIAL - SP (Prof. FELIX)'),
(87, '204 C', '2025-06-17', 'TERÇA', 'Noite', 89, 'Ocupada', 'MCP - TÉCNICO EM QUALIDADE (Prof. LUCELIA)'),
(88, '302 B', '2025-06-17', 'TERÇA', 'Noite', 90, 'Ocupada', 'SED-1 - TÉCNICO EM ELETRÔNICA (Prof. DAVID MS)'),
(89, '105 B', '2025-06-17', 'TERÇA', 'Noite', 91, 'Ocupada', 'PNI - TÉCNICO EM ELETROTÉCNICA (Prof. RILDO WI)'),
(90, '305 B', '2025-06-17', 'TERÇA', 'Noite', 92, 'Ocupada', 'IMEP - TÉCNICO EM ELETROTÉCNICA (Prof. PASCINI)'),
(91, '223 C', '2025-06-17', 'TERÇA', 'Noite', 93, 'Ocupada', 'MCC - TÉCNICO EM VESTUÁRIO - TF 5 (Prof. NEUZA MA)'),
(92, '224 C', '2025-06-17', 'TERÇA', 'Noite', 94, 'Ocupada', 'MCC - TÉCNICO EM VESTUÁRIO - TF 5 (Prof. ANGELO G)'),
(93, '602 B', '2025-06-17', 'TERÇA', 'Noite', 95, 'Ocupada', 'MVFI - TÉCNICO DE AUTOMAÇÃO INDUSTRIAL (Prof. WALFRIDO F)'),
(94, '101 D', '2025-06-17', 'TERÇA', 'Noite', 96, 'Ocupada', 'GSMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. ARNALDO)'),
(95, '119 A', '2025-06-17', 'TERÇA', 'Noite', 97, 'Ocupada', 'SFA - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. EDUARDO VA)'),
(96, '101 D', '2025-06-17', 'TERÇA', 'Noite', 98, 'Ocupada', 'GSMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. ARNALDO)'),
(97, '117 A', '2025-06-17', 'TERÇA', 'Noite', 99, 'Ocupada', 'MMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. FELIPE S)'),
(98, '116 A', '2025-06-17', 'TERÇA', 'Noite', 100, 'Ocupada', 'MMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. IGOR SAVIN)'),
(99, '106 B', '2025-06-17', 'TERÇA', 'Noite', 101, 'Ocupada', 'PEI - TÉCNICO EM ELETROTÉCNICA - 2023/2022 (Prof. CLEBER)'),
(100, '112 A', '2025-06-17', 'TERÇA', 'Noite', 102, 'Ocupada', NULL),
(101, '104 D', '2025-06-17', 'TERÇA', 'Noite', 103, 'Ocupada', NULL),
(102, '115 A', '2025-06-17', 'TERÇA', 'Noite', 104, 'Ocupada', NULL),
(103, '114 A', '2025-06-17', 'TERÇA', 'Noite', 105, 'Ocupada', NULL),
(104, '107 B', '2025-06-17', 'TERÇA', 'Noite', 106, 'Ocupada', NULL),
(105, '205 C', '2025-06-17', 'TERÇA', 'Noite', 107, 'Ocupada', NULL),
(106, '215 C', '2025-06-17', 'TERÇA', 'Noite', 108, 'Ocupada', NULL),
(107, '217 C', '2025-06-18', 'QUARTA', 'Manhã', 109, 'Ocupada', 'GC - AI IMPRESSAO DIGITAL 2025 (Prof. SIDINEY)'),
(108, '119 A', '2025-06-18', 'QUARTA', 'Manhã', 110, 'Ocupada', 'TVA - A.I MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA (Prof. KLEBER)'),
(109, '116 A', '2025-06-18', 'QUARTA', 'Manhã', 111, 'Ocupada', 'TF - APRENDIZAGEM EM MECÂNICA DIESEL (REDUZIDO) - 24 (Prof. JOSE MARIA)'),
(110, '205 C', '2025-06-18', 'QUARTA', 'Manhã', 112, 'Ocupada', 'IA - APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT (Prof. CLAUDIO EL)'),
(111, '214 C', '2025-06-18', 'QUARTA', 'Manhã', 113, 'Ocupada', 'HM - ASSISTENTE DE ESTILO - 2025 (REDUZIDO) (Prof. MILCA)'),
(112, '107 B', '2025-06-18', 'QUARTA', 'Manhã', 114, 'Ocupada', 'FL - APRENDIZAGEM EM GESTAO INDUSTRIAL- TELEMONT (Prof. PAULO EN)'),
(113, '103 B', '2025-06-18', 'QUARTA', 'Manhã', 115, 'Ocupada', 'MD - APRENDIZAGEM MANUT DE MAQUINAS PESADAS FLAPA 2025 (Prof. GUILHERME)'),
(114, '602 B', '2025-06-18', 'QUARTA', 'Manhã', 116, 'Ocupada', 'FE - A.I MANUTENCAO MECANICA DE AUTOMOVEIS STELLANTIS (Prof. LEONARDO)'),
(115, 'GOOGLE CLASS 31', '2025-06-18', 'QUARTA', 'Manhã', 117, 'Ocupada', 'PPE - MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025 (Prof. ROBSON F)'),
(116, '306 B', '2025-06-18', 'QUARTA', 'Manhã', 118, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. PERLA)'),
(117, '208 C', '2025-06-18', 'QUARTA', 'Manhã', 119, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. JULIANA SC)'),
(118, '702 B', '2025-06-18', 'QUARTA', 'Manhã', 120, 'Ocupada', 'FPF - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. JULIO)'),
(119, '105 B', '2025-06-18', 'QUARTA', 'Manhã', 121, 'Ocupada', 'FLDTM - APRENDIZAGEM EM GESTAO INDUSTRIAL 2024/2025 (Prof. MARIO SERG)'),
(120, '212 C-A', '2025-06-18', 'QUARTA', 'Manhã', 122, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. ALINE MAIA)'),
(121, '209 C', '2025-06-18', 'QUARTA', 'Manhã', 123, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. LIDIANE)'),
(122, '213 C-A', '2025-06-18', 'QUARTA', 'Manhã', 124, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. FLAVIA R)'),
(123, '210 C', '2025-06-18', 'QUARTA', 'Manhã', 125, 'Ocupada', 'FTC - FLEXOGRAFIA 2024/2025 (Prof. MARCELO P)'),
(124, '102 D', '2025-06-18', 'QUARTA', 'Manhã', 126, 'Ocupada', 'DS - TÉCNICO EM INFORMÁTICA PARA INTERNET (Prof. CARLOS HEN)'),
(125, '101 D', '2025-06-18', 'QUARTA', 'Manhã', 127, 'Ocupada', 'DS - TÉCNICO EM INFORMÁTICA PARA INTERNET (Prof. FERNANDO L)'),
(126, '119 A', '2025-06-18', 'QUARTA', 'Tarde', 128, 'Ocupada', 'SSD - MANUTENÇÃO MECÂNICA DE AUTOMÓVEIS- VILASA (Prof. LEONARDO)'),
(127, '201 B', '2025-06-18', 'QUARTA', 'Tarde', 129, 'Ocupada', 'SSDVPF - APRENDIZAGEM MECÂNICA DIESEL 03-T-25 (REDUZIDO) (Prof. VALTER)'),
(128, '303 B', '2025-06-18', 'QUARTA', 'Tarde', 130, 'Ocupada', 'ED - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. PEDRO)'),
(129, '107 B', '2025-06-18', 'QUARTA', 'Tarde', 131, 'Ocupada', 'MD - APRENDIZAGEM MANUT. DE MAQUINAS PESADAS FLAPA 2025 (Prof. GUILHERME)'),
(130, 'Oficina Calçados', '2025-06-18', 'QUARTA', 'Tarde', 132, 'Ocupada', 'PPBC - P.E. EM CONFECCAO PRODUTOS DE MALHA (Prof. KAOMA)'),
(131, 'GOOGLE CLASS 31', '2025-06-18', 'QUARTA', 'Tarde', 133, 'Ocupada', 'PPE - MECANICO REPARADOR DE COMPONENTES DE VAGOES - 2025 (Prof. ROBSON F)'),
(132, '504 B', '2025-06-18', 'QUARTA', 'Tarde', 134, 'Ocupada', 'FEHP - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. CLEBER)'),
(133, '601 B', '2025-06-18', 'QUARTA', 'Tarde', 135, 'Ocupada', 'ED - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. PASCINI)'),
(134, '305 B', '2025-06-18', 'QUARTA', 'Tarde', 136, 'Ocupada', 'ISEP - ELETRICISTA DE MANUTENÇÃO ELETROELETRÔNICA (Prof. EDMILSON)'),
(135, '215 C', '2025-06-18', 'QUARTA', 'Tarde', 137, 'Ocupada', 'PI - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. PERLA)'),
(136, '203 C', '2025-06-18', 'QUARTA', 'Tarde', 138, 'Ocupada', 'FL - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. IZABELLE)'),
(137, '203 C', '2025-06-18', 'QUARTA', 'Tarde', 139, 'Ocupada', 'INF - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. IRIZIELAENE)'),
(138, '210 C', '2025-06-18', 'QUARTA', 'Tarde', 140, 'Ocupada', 'FGP - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. BETH)'),
(139, '216 C', '2025-06-18', 'QUARTA', 'Tarde', 141, 'Ocupada', 'FGP - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. FLAVIA R)'),
(140, '209 C', '2025-06-18', 'QUARTA', 'Tarde', 142, 'Ocupada', 'FQ - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. JULIANA SC)'),
(141, '106 B', '2025-06-18', 'QUARTA', 'Tarde', 143, 'Ocupada', 'FLDTM - APRENDIZAGEM EM GESTÃO INDUSTRIAL 2024/2025 (Prof. FELIX)'),
(142, '103 B', '2025-06-18', 'QUARTA', 'Tarde', 144, 'Ocupada', 'FLDM - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. MARIO SERG)'),
(143, '202 B', '2025-06-18', 'QUARTA', 'Tarde', 145, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTÃO INDUSTRIAL COPASA 2025 (Prof. LIDIANE)'),
(144, '213 C-A', '2025-06-18', 'QUARTA', 'Tarde', 146, 'Ocupada', 'APFC - APRENDIZAGEM EM GESTAO INDUSTRIAL COPASA 2025 (Prof. FLAVIA R)'),
(145, '603 B', '2025-06-18', 'QUARTA', 'Noite', 147, 'Ocupada', 'ISEP - TÉCNICO EM ELETROTÉCNICA - PEP 23 (Prof. CRISTHIAN)'),
(146, '204 C', '2025-06-18', 'QUARTA', 'Noite', 148, 'Ocupada', 'MCP - TÉCNICO EM QUALIDADE (Prof. LUCELIA)'),
(147, '302 B', '2025-06-18', 'QUARTA', 'Noite', 149, 'Ocupada', 'SED-1 - TÉCNICO EM ELETRÔNICA (Prof. DAVID MS)'),
(148, '105 B', '2025-06-18', 'QUARTA', 'Noite', 150, 'Ocupada', 'PNI - TÉCNICO EM ELETROTÉCNICA (Prof. RILDO WI)'),
(149, '305 B', '2025-06-18', 'QUARTA', 'Noite', 151, 'Ocupada', 'IMEP - TÉCNICO EM ELETROTÉCNICA (Prof. PASCINI)'),
(150, '224 C', '2025-06-18', 'QUARTA', 'Noite', 152, 'Ocupada', 'MCC - TÉCNICO EM VESTUÁRIO - TF 5 (Prof. NEUZA MA)'),
(151, '223 C', '2025-06-18', 'QUARTA', 'Noite', 153, 'Ocupada', 'MCC - TÉCNICO EM VESTUÁRIO - TF 5 (Prof. ANGELO G)'),
(152, '602 B', '2025-06-18', 'QUARTA', 'Noite', 154, 'Ocupada', 'MVFI - TÉCNICO DE AUTOMAÇÃO INDUSTRIAL (Prof. WALFRIDO F)'),
(153, '101 D', '2025-06-18', 'QUARTA', 'Noite', 155, 'Ocupada', 'GSMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. ARNALDO)'),
(154, '119 A', '2025-06-18', 'QUARTA', 'Noite', 156, 'Ocupada', 'SFA - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. EDUARDO VA)'),
(155, '101 D', '2025-06-18', 'QUARTA', 'Noite', 157, 'Ocupada', 'GSMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. ARNALDO)'),
(156, '117 A', '2025-06-18', 'QUARTA', 'Noite', 158, 'Ocupada', 'MMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. FELIPE S)'),
(157, '116 A', '2025-06-18', 'QUARTA', 'Noite', 159, 'Ocupada', 'MMV - TÉCNICO DE MANUTENÇÃO AUTOMOTIVA (Prof. IGOR SAVIN)'),
(158, '106 B', '2025-06-18', 'QUARTA', 'Noite', 160, 'Ocupada', 'PEI - TÉCNICO EM ELETROTÉCNICA - 2023/2022 (Prof. CLEBER)'),
(159, '112 A', '2025-06-18', 'QUARTA', 'Noite', 161, 'Ocupada', NULL),
(160, '104 D', '2025-06-18', 'QUARTA', 'Noite', 162, 'Ocupada', NULL),
(161, '115 A', '2025-06-18', 'QUARTA', 'Noite', 163, 'Ocupada', NULL),
(162, '114 A', '2025-06-18', 'QUARTA', 'Noite', 164, 'Ocupada', NULL),
(163, '107 B', '2025-06-18', 'QUARTA', 'Noite', 165, 'Ocupada', NULL),
(164, '205 C', '2025-06-18', 'QUARTA', 'Noite', 166, 'Ocupada', NULL),
(165, '215 C', '2025-06-18', 'QUARTA', 'Noite', 167, 'Ocupada', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `instrutores`
--

CREATE TABLE `instrutores` (
  `id_instrutor` int(11) NOT NULL,
  `nome_instrutor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `instrutores`
--

INSERT INTO `instrutores` (`id_instrutor`, `nome_instrutor`) VALUES
(13, 'ALINE MAIA'),
(36, 'ANDERSON PEREIRA DA SILVA'),
(29, 'ANGELO G'),
(31, 'ARNALDO'),
(44, 'BETH'),
(41, 'BRUNO ASS'),
(46, 'CARLOS HEN'),
(3, 'CLAUDIO EL'),
(19, 'CLEBER'),
(38, 'CRISTHIAN'),
(26, 'DAVID MS'),
(48, 'EAD 6'),
(49, 'EAD 7'),
(21, 'EDMILSON'),
(32, 'EDUARDO VA'),
(33, 'FELIPE S'),
(23, 'FELIX'),
(47, 'FERNANDO L'),
(24, 'FLAVIA R'),
(6, 'GUILHERME'),
(39, 'HERNANNY'),
(34, 'IGOR SAVIN'),
(22, 'IRIZIELAENE'),
(45, 'IZABELLE'),
(37, 'JOSE MARIA'),
(42, 'JOSÉ R'),
(10, 'JULIANA SC'),
(11, 'JULIO'),
(18, 'KAOMA'),
(2, 'KLEBER'),
(7, 'LEONARDO'),
(14, 'LIDIANE'),
(25, 'LUCELIA'),
(43, 'MARCELO P'),
(15, 'MARINALVA'),
(12, 'MARIO SERG'),
(4, 'MILCA'),
(28, 'NEUZA MA'),
(20, 'PASCINI'),
(5, 'PAULO EN'),
(17, 'PEDRO'),
(9, 'PERLA'),
(27, 'RILDO WI'),
(8, 'ROBSON F'),
(40, 'RODRIGO BE'),
(1, 'SIDINEY'),
(16, 'VALTER'),
(30, 'WALFRIDO F'),
(35, 'WEMERSON');

-- --------------------------------------------------------

--
-- Estrutura da tabela `materias`
--

CREATE TABLE `materias` (
  `id_materia` int(11) NOT NULL,
  `nome_materia` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `materias`
--

INSERT INTO `materias` (`id_materia`, `nome_materia`) VALUES
(1, 'GC'),
(2, 'TVA'),
(3, 'IA'),
(4, 'HM'),
(5, 'FL'),
(6, 'MD'),
(7, 'FE'),
(8, 'PPE'),
(9, 'FQ'),
(10, 'FPF'),
(11, 'FLDTM'),
(12, 'APFC'),
(13, 'SSD'),
(14, 'SSDVPF'),
(15, 'ED'),
(16, 'MD'),
(17, 'PPBC'),
(18, 'FEHP'),
(19, 'PI'),
(20, 'FL'),
(21, 'INF'),
(22, 'FGP'),
(23, 'FQ'),
(24, 'FLDTM'),
(25, 'FLDM'),
(26, 'APFC'),
(27, 'MCP'),
(28, 'HT-ELT'),
(29, 'PNI'),
(30, 'IMEP'),
(31, 'MCC'),
(32, 'PEP-E1'),
(33, 'MVFI'),
(34, 'GSMV'),
(35, 'SFA'),
(36, 'MMV'),
(37, 'PEI'),
(38, 'GC'),
(39, 'TVA'),
(40, 'IA'),
(41, 'HM'),
(42, 'FL'),
(43, 'MD'),
(44, 'FE'),
(45, 'PPE'),
(46, 'PI'),
(47, 'FQ'),
(48, 'FPF'),
(49, 'FLDTM'),
(50, 'SSD'),
(51, 'SSDVPF'),
(52, 'ED'),
(53, 'PPBC'),
(54, 'FEHP'),
(55, 'ISEP'),
(56, 'INF'),
(57, 'FGP'),
(58, 'FQ'),
(59, 'FLDM'),
(60, 'APFC'),
(61, 'MCP'),
(62, 'HT-ELT'),
(63, 'PNI'),
(64, 'IMEP'),
(65, 'MCC'),
(66, 'PEP-E1'),
(67, 'MVFI'),
(68, 'GSMV'),
(69, 'SFA'),
(70, 'MMV'),
(71, 'PEI'),
(72, 'AFASTAMENTO LEGAL'),
(73, 'GC'),
(74, 'TVA'),
(75, 'IA'),
(76, 'HM'),
(77, 'FL'),
(78, 'MD'),
(79, 'FE'),
(80, 'PPE'),
(81, 'PI'),
(82, 'FQ'),
(83, 'FPF'),
(84, 'FLDTM'),
(85, 'SSD'),
(86, 'SSDVPF'),
(87, 'ED'),
(88, 'PPBC'),
(89, 'FEHP'),
(90, 'ISEP'),
(91, 'INF'),
(92, 'FGP'),
(93, 'FQ'),
(94, 'FLDM'),
(95, 'APFC'),
(96, 'MCP'),
(97, 'HT-ELT'),
(98, 'PNI'),
(99, 'IMEP'),
(100, 'MCC'),
(101, 'PEP-E1'),
(102, 'MVFI'),
(103, 'GSMV'),
(104, 'SFA'),
(105, 'MMV'),
(106, 'PEI'),
(107, 'AFASTAMENTO LEGAL'),
(108, 'MCP'),
(109, 'SED-1'),
(110, 'PNI'),
(111, 'IMEP'),
(112, 'MCC'),
(113, 'PEP-E1'),
(114, 'MVFI'),
(115, 'GSMV'),
(116, 'SFA'),
(117, 'MMV'),
(118, 'PEI');

-- --------------------------------------------------------

--
-- Estrutura da tabela `salas`
--

CREATE TABLE `salas` (
  `id_sala` int(11) NOT NULL,
  `numero_sala` varchar(50) NOT NULL,
  `capacidade` int(11) DEFAULT NULL,
  `localizacao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `salas`
--

INSERT INTO `salas` (`id_sala`, `numero_sala`, `capacidade`, `localizacao`) VALUES
(1, '217 C', NULL, NULL),
(2, '119 A', NULL, NULL),
(3, '205 C', NULL, NULL),
(4, '223 C', NULL, NULL),
(5, '107 B', NULL, NULL),
(6, '103 B', NULL, NULL),
(7, '602 B', NULL, NULL),
(8, 'GOOGLE CLASS 31', NULL, NULL),
(9, '306 B', NULL, NULL),
(10, '212 C-A', NULL, NULL),
(11, '702 B', NULL, NULL),
(12, '105 B', NULL, NULL),
(13, '213 C-A', NULL, NULL),
(14, '206 C', NULL, NULL),
(15, '203 C', NULL, NULL),
(16, '201 B', NULL, NULL),
(17, '303 B', NULL, NULL),
(18, 'Oficina Calçados', NULL, NULL),
(19, '504 B', NULL, NULL),
(20, '601 B', NULL, NULL),
(21, '305 B', NULL, NULL),
(22, '215 C', NULL, NULL),
(23, '101 B', NULL, NULL),
(24, '210 C', NULL, NULL),
(25, '216 C', NULL, NULL),
(26, '209 C', NULL, NULL),
(27, '106 B', NULL, NULL),
(28, '202 B', NULL, NULL),
(34, '204 C', NULL, NULL),
(35, '302 B', NULL, NULL),
(36, '304 B', NULL, NULL),
(37, '224 C', NULL, NULL),
(38, '104 B', NULL, NULL),
(39, '101 D', NULL, NULL),
(40, '117 A', NULL, NULL),
(41, '116 A', NULL, NULL),
(42, '112 A', NULL, NULL),
(127, '116', 30, 'Bloco B');

-- --------------------------------------------------------

--
-- Estrutura da tabela `turmas`
--

CREATE TABLE `turmas` (
  `id_turma` int(11) NOT NULL,
  `nome_turma` varchar(100) NOT NULL,
  `detalhes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `turmas`
--

INSERT INTO `turmas` (`id_turma`, `nome_turma`, `detalhes`) VALUES
(1, '217 C', NULL),
(2, '119 A', NULL),
(3, '205 C', NULL),
(4, '223 C', NULL),
(5, '107 B', NULL),
(6, '103 B', NULL),
(7, '602 B', NULL),
(8, 'GOOGLE CLASS 31', NULL),
(9, '306 B', NULL),
(10, '212 C-A', NULL),
(11, '702 B', NULL),
(12, '105 B', NULL),
(13, '213 C-A', NULL),
(14, '206 C', NULL),
(15, '203 C', NULL),
(16, 'AI-MMA-01-M', NULL),
(17, 'AI-MCD-02-M', NULL),
(18, 'AI-EME-02-M', NULL),
(19, 'AI-ASS-01-M', NULL),
(20, 'AI-CPPM-01-M', NULL),
(21, 'AI-MCV-01-M', NULL),
(22, 'AI-EME-01-M', NULL),
(23, 'AI-GEI-01-M', NULL),
(24, 'AI-GEI-14-M', NULL),
(25, 'AI-GEI-17-T-24', NULL),
(26, 'AI-GEI-18-T-24', NULL),
(27, 'AI-GEI-19-T-24', NULL),
(28, 'AI-GEI-02-T-24', NULL),
(29, 'AI-GEI-03-T-25', NULL),
(30, 'AI-GEI-07-T-25', NULL),
(31, 'AI-GEI-08-T-25', NULL),
(32, 'AI-FLG-01-M', NULL),
(33, 'HT-QUA-01-N-25', NULL),
(34, 'HT-ELT-01-N-25', NULL),
(35, 'HT-ETT-02-N-24', NULL),
(36, 'HT-ETT-01-N-25', NULL),
(37, 'HT-VES-03-N-25', NULL),
(38, 'HT-VES-04-N-25', NULL),
(39, 'HTELET-01-N-24', NULL),
(40, 'HT-AUT-05-N-24', NULL),
(41, 'HT-MAA-03-N-24', NULL),
(42, 'HT-MAA-04-N-24', NULL),
(43, 'HT-MAA-09-N-24', NULL),
(44, 'HT-MAA-10-N-24', NULL),
(45, 'HT-ETT-06-N-24', NULL),
(46, 'AI-DIG-02-M-25', NULL),
(47, 'AI-MANUTENCAO MECANICA DE AUTOMOVEIS LOCALIZA', NULL),
(48, 'AI-GEI-12-M-25', NULL),
(49, 'AI-ASS-01-M-25', NULL),
(50, 'AI-EME-02-M-25', NULL),
(51, 'AI-MCD-01-M-25', NULL),
(52, 'AI-MCV-01-M-25', NULL),
(53, 'AI-GEI-01-M-24', NULL),
(54, 'AI-GEI-11-M-24', NULL),
(55, 'AI-GEI-10-M-25', NULL),
(56, 'AI-GEI-02-M-25', NULL),
(57, 'AI-GEI-06-M-25', NULL),
(58, 'AI-FLG-03-M-25', NULL),
(59, '', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`) VALUES
(2, 'teste', 'marco@email.com', 'teste123teste');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `aulas`
--
ALTER TABLE `aulas`
  ADD PRIMARY KEY (`id_aula`);

--
-- Índices para tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id_curso`),
  ADD UNIQUE KEY `codigo_curso` (`codigo_curso`);

--
-- Índices para tabela `horario_instrutor_consulta`
--
ALTER TABLE `horario_instrutor_consulta`
  ADD PRIMARY KEY (`id_horario_instrutor_consulta`),
  ADD KEY `id_instrutor` (`id_instrutor`),
  ADD KEY `id_aula` (`id_aula`);

--
-- Índices para tabela `horario_sala_consulta`
--
ALTER TABLE `horario_sala_consulta`
  ADD PRIMARY KEY (`id_horario_sala_consulta`),
  ADD KEY `id_aula` (`id_aula`);

--
-- Índices para tabela `instrutores`
--
ALTER TABLE `instrutores`
  ADD PRIMARY KEY (`id_instrutor`),
  ADD UNIQUE KEY `nome_instrutor` (`nome_instrutor`);

--
-- Índices para tabela `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`id_materia`);

--
-- Índices para tabela `salas`
--
ALTER TABLE `salas`
  ADD PRIMARY KEY (`id_sala`),
  ADD UNIQUE KEY `numero_sala` (`numero_sala`);

--
-- Índices para tabela `turmas`
--
ALTER TABLE `turmas`
  ADD PRIMARY KEY (`id_turma`),
  ADD UNIQUE KEY `nome_turma` (`nome_turma`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aulas`
--
ALTER TABLE `aulas`
  MODIFY `id_aula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT de tabela `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT de tabela `horario_instrutor_consulta`
--
ALTER TABLE `horario_instrutor_consulta`
  MODIFY `id_horario_instrutor_consulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT de tabela `horario_sala_consulta`
--
ALTER TABLE `horario_sala_consulta`
  MODIFY `id_horario_sala_consulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT de tabela `instrutores`
--
ALTER TABLE `instrutores`
  MODIFY `id_instrutor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT de tabela `materias`
--
ALTER TABLE `materias`
  MODIFY `id_materia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT de tabela `salas`
--
ALTER TABLE `salas`
  MODIFY `id_sala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT de tabela `turmas`
--
ALTER TABLE `turmas`
  MODIFY `id_turma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `horario_instrutor_consulta`
--
ALTER TABLE `horario_instrutor_consulta`
  ADD CONSTRAINT `horario_instrutor_consulta_ibfk_1` FOREIGN KEY (`id_instrutor`) REFERENCES `instrutores` (`id_instrutor`),
  ADD CONSTRAINT `horario_instrutor_consulta_ibfk_2` FOREIGN KEY (`id_aula`) REFERENCES `aulas` (`id_aula`);

--
-- Limitadores para a tabela `horario_sala_consulta`
--
ALTER TABLE `horario_sala_consulta`
  ADD CONSTRAINT `horario_sala_consulta_ibfk_1` FOREIGN KEY (`id_aula`) REFERENCES `aulas` (`id_aula`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
