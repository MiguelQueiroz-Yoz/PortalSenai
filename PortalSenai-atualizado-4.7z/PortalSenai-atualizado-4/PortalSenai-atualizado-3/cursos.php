<?php
include 'conexao.php';

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo_curso = $_POST['codigo_curso'] ?? '';
    $nome_curso = $_POST['nome_curso'] ?? '';

    if (!empty($codigo_curso) && !empty($nome_curso)) {
        $stmt = $conn->prepare("INSERT INTO cursos (codigo_curso, nome_curso) VALUES (?, ?)");
        $stmt->bind_param("ss", $codigo_curso, $nome_curso);

        if ($stmt->execute()) {
            $mensagem = "<p class='mensagem sucesso'>Curso cadastrado com sucesso!</p>";
        } else {
            $mensagem = "<p class='mensagem erro'>Erro ao cadastrar curso: " . $stmt->error . "</p>";
        }

        $stmt->close();
    } else {
        $mensagem = "<p class='mensagem erro'>Preencha todos os campos.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas - Sala</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .mensagem {
            margin-top: 15px;
            text-align: center;
            font-size: 14px;
        }

        .sucesso {
            color: green;
        }

        .erro {
            color: red;
        }

        .form-container {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-box label {
            display: block;
            margin-bottom: 5px;
        }

        .form-box input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .form-box button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-box button:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="salas.php">Salas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horários</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>
    <div class="form-container">
        <div class="form-box">
            <h2>Cadastrar Curso</h2>
            <form method="post">
                <label for="codigo_curso">Código do Curso:</label>
                <input type="text" name="codigo_curso" id="codigo_curso" required>

                <label for="nome_curso">Nome do Curso:</label>
                <input type="text" name="nome_curso" id="nome_curso" required>

                <button type="submit">Cadastrar Curso</button>
                <?= $mensagem ?>
            </form>
        </div>
    </div>
    <div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
            <div class="vw-plugin-top-wrapper"></div>
        </div>
        </div>
        <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
        <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
        </script>
</body>
</html>
