<?php
include 'conexao.php';

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero_sala = $_POST['numero_sala'];
    $capacidade = $_POST['capacidade'];
    $localizacao = $_POST['localizacao'];

    if (!empty($numero_sala) && !empty($capacidade) && !empty($localizacao)) {
        $stmt = $conn->prepare("INSERT INTO salas (numero_sala, capacidade, localizacao) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $numero_sala, $capacidade, $localizacao);

        if ($stmt->execute()) {
            $mensagem = "<p class='mensagem sucesso'>Sala cadastrada com sucesso!</p>";
        } else {
            $mensagem = "<p class='mensagem erro'>Erro ao cadastrar sala: " . $stmt->error . "</p>";
        }

        $stmt->close();
    } else {
        $mensagem = "<p class='mensagem erro'>Preencha todos os campos.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas - Sala</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        header {
            width: 96%;
            max-width: none;
            margin: 0 auto;
            border-radius: 0;
        }

        .form-container {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-box label {
            display: block;
            margin-bottom: 5px;
        }

        .form-box input[type="text"],
        .form-box input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .form-box button {
            width: 100%;
            padding: 10px;
            background-color: #004aad;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-box button:hover {
            background-color: #003b87;
        }

        .mensagem {
            margin-top: 15px;
            text-align: center;
            font-size: 14px;
        }

        .sucesso {
            color: green;
        }

        .erro {
            color: red;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="professor-header">
            <div class="header-left">
                <div class="logo">
                    <img src="logo-senai.png" alt="SESI SENAI">
                </div>
            </div>
            <div class="header-center">
                <div class="title">NETNÚCLEO - HORTO</div>
                <nav class="main-nav">
                    <ul>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Cadastros</a>
                            <div class="dropdown-content">
                                <a href="salas.php">Salas</a>
                                <a href="cursos.php">Cursos</a>
                                <a href="turmas.php">Turmas</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropbtn">Consultas</a>
                            <div class="dropdown-content">
                                <a href="consulta_horario.php">Horários</a>
                                <a href="consulta_instrutor.php">Instrutor</a>
                                <a href="consulta_sala.php">Sala</a>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <button id="theme-toggle" class="theme-toggle-button" title="Alternar Tema">
                    🌙
                </button>
            </div>
        </header>
    <div class="form-container">
        <div class="form-box">
            <h2>Cadastro de Sala</h2>
            <form method="POST">
                <label for="numero_sala">Número da Sala:</label>
                <input type="text" name="numero_sala" id="numero_sala" required>

                <label for="capacidade">Capacidade:</label>
                <input type="number" name="capacidade" id="capacidade" required>

                <label for="localizacao">Localização:</label>
                <input type="text" name="localizacao" id="localizacao" required>

                <button type="submit">Cadastrar Sala</button>
                <?= $mensagem ?>
            </form>
        </div>
    </div>
    <div vw class="enabled">
    <div vw-access-button class="active"></div>
    <div vw-plugin-wrapper>
        <div class="vw-plugin-top-wrapper"></div>
    </div>
    </div>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
    <script>
    new window.VLibras.Widget('https://vlibras.gov.br/app');
    </script>
</body>
</html>
